# When it breaks

Almost everything that goes wrong here is one of these seven. Work down the list before assuming the code is wrong.

## 0. Two things to rule out first

Both look like code bugs and neither is one:

- **`251001: Account must be specified`** — `app/backend/.env` is empty or missing values. Nothing will query until `SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_USER` and `SNOWFLAKE_WAREHOUSE` are filled in. Ask Claude for "help me fill in my Snowflake settings" and it will ask you for the values and write them in.
- **A query that hangs, then times out** — you are off the VPN. Snowflake is only reachable from the JBS network, so working from home means connecting to the VPN first. Connect, then reload the page; no restart needed.

## 1. A browser window keeps asking me to sign in

Expected once, on the first query after starting the backend. Expected *every* query means the login isn't being cached.

The cache needs the `secure-local-storage` extra, which `pyproject.toml` already declares. If it's prompting repeatedly, the backend log will say `Dependency 'keyring' is not installed`. Fix:

```powershell
cd app/backend
uv sync
```

Then restart the backend. Also: don't fire several queries at once on a cold start — the backend serializes connects so a page with four charts costs one login, but a page that starts before the first login finishes will wait on it.

## 2. "Object does not exist, or operation cannot be performed"

Snowflake's message for both "no such table" *and* "your role can't see that table", and it does not distinguish them. Check the role first:

```powershell
uv run .claude/skills/exploring-snowflake/scripts/sf.py whoami
```

That prints your current role and every role you hold. If `SNOWFLAKE_ROLE` in `app/backend/.env` is blank you are on `PUBLIC`, which sees a fraction of the account. Set it to a role that actually holds the grant and restart the backend.

Then confirm the table exists at all — `sf.py find <NAME>` — before touching the query.

## 3. The page is blank, or a chart area is empty

Open the browser console (F12). Then, in order:

- **Red error in the console** — a code problem. The message names the file and line.
- **Nothing in the console, empty chart** — the query returned zero rows. Run it in the Explore tab. A filter that reads `where PLANT = 'Plant A'` against data that says `PLANT_A` returns nothing, successfully.
- **A number that shows up but looks wrong** — not a break, but say so anyway: "this total doesn't match my spreadsheet" or "we don't have that many plants". Claude has a checklist for exactly this, and it will tell you which of the two is wrong rather than quietly adjusting the number to match.
- **Numbers show as `—`** — the column name in the page doesn't match what the query returned. Snowflake returns column names uppercased unless they were quoted, so `row.total_cases` is `undefined` where `row.TOTAL_CASES` works.

## 4. 502, or "Query failed"

The backend reached Snowflake and Snowflake refused. The real message is in the backend terminal window and in the error shown on the card. Common causes, in order: wrong role (see 2), a warehouse that is suspended or not set, SQL syntax, or being off the VPN.

## 5. I lost something, or it was better before

Don't try to fix it yourself and don't undo anything by hand. Say what you want back, as plainly as you'd say it to a person:

- "Undo the last thing you did."
- "The chart was better before you changed the colors — put it back."
- "Go back to how the whole page looked yesterday."
- "What have we changed today?"

Claude keeps a saved copy every time you say you like something, so it can bring any of those versions back. If you're not sure when it was still right, ask for the list of what changed and pick from it.

## 6. It won't start at all

- `pnpm: command not found` → `npm install -g pnpm`
- `uv: command not found` → `winget install --id=astral-sh.uv`
- `Port 5173 is in use` → it is already running. Look for the browser tab before starting a second copy.
- Changes not showing up → check both terminal windows. A TypeScript error stops the page from rebuilding and prints in the frontend window; the page keeps showing the last version that worked.

---

**Still stuck?** Tell Claude what you saw, including anything red in the two terminal windows. It can read those directly.
