# Packages this kit for sharing. Excludes installed packages, build output and
# any .env, so no credentials leave with it.
#
#   .\make-zip.ps1                      -> pilgrims-vibecoding.zip next to this folder
#   .\make-zip.ps1 -Output C:\tmp\x.zip

param([string]$Output)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (-not $Output) { $Output = Join-Path (Split-Path $root -Parent) 'pilgrims-vibecoding.zip' }

$staging = Join-Path ([System.IO.Path]::GetTempPath()) ("vibekit-" + [guid]::NewGuid().ToString('N'))
$dest = Join-Path $staging 'pilgrims-vibecoding'
New-Item -ItemType Directory -Path $dest -Force | Out-Null

$exclude = @('node_modules', 'dist', '.venv', '__pycache__', '.git')

Get-ChildItem -Path $root -Recurse -Force -File | ForEach-Object {
    $relative = $_.FullName.Substring($root.Length).TrimStart('\')
    $parts = $relative.Split('\')
    if ($parts | Where-Object { $exclude -contains $_ }) { return }
    if ($_.Name -eq '.env') { return }
    if ($_.Name -eq 'pilgrims-vibecoding.zip') { return }

    $target = Join-Path $dest $relative
    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item $_.FullName $target
}

if (Test-Path $Output) { Remove-Item $Output -Force }
Compress-Archive -Path $dest -DestinationPath $Output
Remove-Item $staging -Recurse -Force

$size = [math]::Round((Get-Item $Output).Length / 1MB, 2)
Write-Host "Created $Output ($size MB)" -ForegroundColor Green
Write-Host "Recipients unzip it, open the folder in Claude Code, and say 'start the app'."
