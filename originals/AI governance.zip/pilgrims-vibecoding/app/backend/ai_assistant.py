"""Bridge to the data team's AI assistant.

That assistant is a separate prototype and doesn't exist yet. This module is
the plug for it: set AI_ASSISTANT_URL once it's up and `ask` starts
forwarding questions there for real. Until then it returns a clearly-labeled
placeholder answer so the "Ask AI" panel can be demoed end to end.

Expected contract, once AI_ASSISTANT_URL is set: a POST with
{"source": {...catalogue source...}, "question": "..."} returning
{"answer": "..."}. Adjust `_call_assistant` if the real service's contract
ends up different.
"""

from __future__ import annotations

import asyncio
import json
import os
import urllib.error
import urllib.request
from typing import Any

AI_ASSISTANT_URL = os.getenv("AI_ASSISTANT_URL")
_TIMEOUT_SECONDS = 20


class AssistantError(RuntimeError):
    """The configured AI assistant didn't answer."""


def _call_assistant(url: str, payload: dict[str, Any]) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=_TIMEOUT_SECONDS) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise AssistantError(str(exc)) from exc


def _placeholder_answer(source: dict[str, Any], question: str) -> str:
    return (
        f"(Demo answer — no AI assistant connected yet.) You asked about "
        f"{source['code']}: \u201c{question}\u201d. Once AI_ASSISTANT_URL is set in "
        f"app/backend/.env, this panel will forward the question there and show "
        f"the real answer instead."
    )


async def ask(source: dict[str, Any], question: str) -> dict[str, Any]:
    if not AI_ASSISTANT_URL:
        return {"answer": _placeholder_answer(source, question), "connected": False}

    try:
        result = await asyncio.to_thread(
            _call_assistant, AI_ASSISTANT_URL, {"source": source, "question": question}
        )
        return {"answer": result.get("answer", ""), "connected": True}
    except AssistantError:
        return {
            "answer": "The AI assistant is configured but didn't respond. Showing the demo answer instead: "
            + _placeholder_answer(source, question),
            "connected": False,
        }
