# Build your own Control Tower or custom application

This folder is a working prototype of a Control Tower app — a web page that pulls data out of Snowflake and turns it into charts. It already runs. Your job is to describe what you want; Claude changes it.

You do not need to know how to code. You do not need to read any of the files here.

---

## Set up once

**1. Install three things.** If you have never installed anything from a terminal, open Claude Code (step 2) first and ask it to walk you through this — it can check what you already have.

| What | How |
|---|---|
| Node.js | Download the **LTS** version from [nodejs.org](https://nodejs.org) and click through the installer |
| pnpm | Open PowerShell and run `npm install -g pnpm` |
| uv | Open PowerShell and run `winget install --id=astral-sh.uv` |
| Git | Open PowerShell and run `winget install --id Git.Git` — this is what keeps a copy of every version you liked |

**2. Open this folder in Claude Code.** In VS Code: *File → Open Folder*, pick this folder, then open Claude Code. Or in a terminal, `cd` into this folder and run `claude`.

**3. Say this:**

> start the app

Claude runs everything and opens it in your browser. The first time, it will also ask for your Snowflake details — your account name, your username, and your role. If you don't know them, say so and it will help you find them.

The very first query opens a Microsoft sign-in window. That is normal, and it only happens once.

---

## Then just ask

You are talking to someone who can see your data and build screens. Talk to them like that.

> Find the table with weekly broiler placements and show me the last 12 weeks as a line chart.

> Add a dropdown to filter this by plant.

> This number looks wrong. Show me the query you used.

> Make the top three tiles show total cases, average yield, and number of plants reporting.

> I want a second page comparing this year to last year, by region.

> Show me what tables exist about customer orders.

> This total doesn't match my spreadsheet — can you check it?

> Add a button to download this table as Excel.

Two habits make this work much better:

- **Say what you want to see, not how to build it.** "A bar chart of volume by plant, biggest first" beats "add a BarChart component".
- **React to what you get.** "Too cluttered, drop the bottom table" and "these colors don't separate well" are exactly the right kind of feedback. Nothing here is precious — it's a prototype.

---

### Shortcuts

Plain English always works, but these save typing. Type the slash and Claude offers the list.

| Type | What it does |
|---|---|
| `/start` | Starts the app, and sets it up if this is the first time |
| `/save` | Saves this version so it can be brought back later |
| `/undo` | Goes back to an earlier version |
| `/check-number` | Checks a figure you think is wrong |
| `/handoff` | Packages the whole thing up for the engineering team |

---

## Nothing you build gets lost

Claude saves a copy every time you say you like something. You never have to ask for it and there is nothing to click. It means you can say things like:

> That was better before you changed the colors. Put it back.

> Go back to how the page looked yesterday.

> What have we built so far?

So experiment freely — asking for something bold and hating it costs you nothing.

## When it's good enough for real

A prototype on your laptop is where this stops. When something here is genuinely useful and you want the platform team to build the real version, say:

> Hand this off to engineering.

Claude will ask you a handful of business questions — who reads this, how fresh the data needs to be, who should be allowed to see it — and then write the whole thing up: what it does, the exact queries behind every number, the rules you decided along the way, and what the engineers need to decide. You get a zip file to send them.

That write-up is the point. A working prototype plus a document explaining it is a far better brief than a meeting.

## What's in the box

- A **Dashboard** page with example charts, running on sample data Snowflake generates on the fly. It works before you have found a single real table, which is how you know your connection is good.
- An **Explore data** page where you (or Claude) can run a query and see the rows. Useful when a number looks wrong.
- The same colors, fonts and components as the real Control Tower apps, so what you build looks like the real thing.

## The limits, honestly

- **It can only read.** Nothing you build here can change data in Snowflake. That is deliberate and cannot be turned on.
- **You only see what your Snowflake role can see.** If a table seems missing, it is usually a permissions thing, not a bug. Claude knows how to check.
- **This is a prototype, not a product.** It runs on your machine only. Nobody else can open it, and it is not going to production as-is. When something here turns out to be genuinely useful, that is the moment to hand it to the platform team — say "hand this off to engineering" and Claude packages it up for them.

## When something breaks

Tell Claude what you saw. "The page is blank", "it says 502", "it's been spinning for a minute" is enough — it knows where the logs are. `troubleshooting.md` has the five things that usually go wrong if you want to look yourself.
