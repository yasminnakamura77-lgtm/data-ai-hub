#!/usr/bin/env bash
# Starts the app. Run with:  ./start.sh
# Ctrl+C stops both halves.

set -e
root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
backend="$root/app/backend"
frontend="$root/app/frontend"

need() {
  command -v "$1" >/dev/null 2>&1 || { echo; echo "Missing: $1"; echo "$2"; echo; exit 1; }
}

need node 'Install Node.js from https://nodejs.org (pick the LTS version), then run this again.'
need pnpm 'Run this once:  npm install -g pnpm'
need uv   'Run this once:  curl -LsSf https://astral.sh/uv/install.sh | sh'

if [ ! -f "$backend/.env" ]; then
  cp "$backend/.env.example" "$backend/.env"
  echo
  echo "Created app/backend/.env - fill in your Snowflake details before queries will work."
  echo "Ask Claude: 'help me fill in my Snowflake settings'"
  echo
fi

if [ ! -d "$frontend/node_modules" ]; then
  echo "Installing frontend packages (one time, ~1 minute)..."
  (cd "$frontend" && pnpm install)
fi

trap 'kill 0' EXIT
(cd "$backend" && uv run uvicorn main:app --reload --port 8000) &
(cd "$frontend" && pnpm dev) &

echo
echo "Open http://localhost:5173 in your browser."
echo "The first query opens a Microsoft sign-in window. That is expected."
wait
