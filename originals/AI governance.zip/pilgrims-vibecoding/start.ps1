# Starts the app. Right-click this file -> "Run with PowerShell", or ask Claude to run it.
# Opens two windows (the backend and the frontend). Closing them stops the app.

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$backend = Join-Path $root 'app\backend'
$frontend = Join-Path $root 'app\frontend'

function Test-Tool($name, $installHint) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        Write-Host ""
        Write-Host "Missing: $name" -ForegroundColor Red
        Write-Host $installHint
        Write-Host ""
        exit 1
    }
}

Test-Tool 'node' 'Install Node.js from https://nodejs.org (pick the LTS version), then run this again.'
Test-Tool 'pnpm' 'Run this once:  npm install -g pnpm'
Test-Tool 'uv'   'Run this once:  winget install --id=astral-sh.uv'

if (-not (Test-Path (Join-Path $backend '.env'))) {
    Copy-Item (Join-Path $backend '.env.example') (Join-Path $backend '.env')
    Write-Host ""
    Write-Host "Created app\backend\.env - fill in your Snowflake details before queries will work." -ForegroundColor Yellow
    Write-Host "Ask Claude: 'help me fill in my Snowflake settings'"
    Write-Host ""
}

if (-not (Test-Path (Join-Path $frontend 'node_modules'))) {
    Write-Host "Installing frontend packages (one time, ~1 minute)..." -ForegroundColor Cyan
    Push-Location $frontend
    pnpm install
    Pop-Location
}

Write-Host "Starting backend on http://localhost:8000 ..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$backend'; uv run uvicorn main:app --reload --port 8000"

Write-Host "Starting frontend on http://localhost:5173 ..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$frontend'; pnpm dev"

Start-Sleep -Seconds 4
Start-Process 'http://localhost:5173'

Write-Host ""
Write-Host "Open http://localhost:5173 in your browser." -ForegroundColor Green
Write-Host "The first query opens a Microsoft sign-in window. That is expected."
