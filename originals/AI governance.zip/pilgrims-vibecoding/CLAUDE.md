# Pilgrim's Vibecoding Kit

A working Control Tower prototype — React frontend, Python backend, Snowflake behind it — plus the skills to extend it. This file is loaded automatically every session. Read it before doing anything else.

## Who you are working with

**Assume the person you are talking to does not read code and does not want to.** They know their business — sales, live operations, plant, master data — and they know what report would help them. They do not know React, Python, git, or the terminal, and nothing here should require them to.

They are not fragile, and they are not children. Explain trade-offs plainly when a decision is actually theirs ("do you want this by plant or by region?"). Do not explain how a `useState` works, do not paste code into chat, and do not walk them through a file diff. What they want to see is **the app, in the browser, doing the thing.**

So:

- **Run the commands yourself.** Never end a turn with "now run `pnpm install`". You have a terminal; use it.
- **Finish in the browser.** End with what changed and where to look: "Reload http://localhost:5173 — the plant chart is now on the Dashboard tab." If it's already running, Vite has already reloaded it.
- **Say what you actually did**, including when something didn't work. A query that returned nothing is a finding, not a failure to hide.
- **Ask about the business, not the implementation.** "Which date column counts — order date or ship date?" is a good question. "Should I use a bar chart or a `<BarChart>` component?" is not.

## What this is for

Prototypes. Things that answer "would this report be useful?" in an afternoon. They do not need to be fast, secure, tested, or well-structured, and no one will deploy them. **Getting to a screen the person can react to beats getting it right.** If you are weighing an abstraction against just writing the thing twice, write it twice.

This is deliberately *not* how the real Control Tower repos are built. Do not import a rule from those repos into this one because it sounds professional.

## The layout

```
app/frontend/src/
  pages/          one file per screen — this is where you spend your time
  ui/             the component kit (see the pilgrims-look-and-feel skill)
  lib/use-sql.ts  useSql() — runs a query, gives you rows
  lib/format.ts   formatNumber, formatCurrency, formatPercent, formatDate
  App.tsx         the page list and the nav
app/backend/
  main.py         the API. One endpoint: POST /api/query
  warehouse.py    the Snowflake connection
  guard.py        rejects anything that isn't a read
```

Two commands run it, both handled by `start.ps1` (Windows) / `start.sh` (Mac):

- backend: `uv run uvicorn main:app --reload --port 8000` in `app/backend`
- frontend: `pnpm dev` in `app/frontend`

Both reload on save. **You almost never need to restart them** — if the person says "it's not updating", check the two terminal windows for an error before restarting anything.

## How a report gets built

0. **Make sure their last version is saved.** `git status --short` — if there's uncommitted work, commit it before you start changing things. `git-flow` has the rules; the short version is that they cannot read a diff, so history is the only way "put the chart back" is answerable.
1. **Find the data.** Use the `exploring-snowflake` skill. Never guess a table name — a plausible-sounding table that doesn't exist wastes the person's afternoon, and this account has QA clones that look exactly like the real thing.
2. **Get the query right first**, in the Explore tab or with `sf.py`. One query returning the right shape beats a beautiful page wired to nothing.
3. **Build the page** from `src/ui` — see `building-a-dashboard`.
4. **Look at it.** If you can, open it. If not, tell the person exactly what to check.

## Rules that matter

- **Reads only.** The backend rejects `insert`, `update`, `drop` and anything else that writes. This is not an obstacle to route around — nobody prototyping needs to write to the warehouse, and this kit will never do it. If someone asks, say no and explain that changing warehouse data goes through the real MDM platform.
- **Use `src/ui`.** It is a copy of the real `@pilgrims/ui`, with the same colors, spacing and components, which is the whole reason a prototype from here looks like the real product. Do not hand-roll a `<div class="border rounded p-4">` card, and do not add a component library.
- **`useSql` for everything.** No react-query, no axios, no state manager, no router. If a page needs a filter, `useState` plus a template string in the SQL is the answer.
- **Barely comment.** The person will never read this code, and you will re-read it fine without narration. Comment only the thing that would look like a mistake otherwise.
- **Don't add tooling.** No tests, no linter, no Docker, no CI, no database. If a task seems to need one, it has left what this kit is for.
- **Ask before deleting their work.** Adding a page is free. Replacing one they liked is not. **Commit before you replace anything** — see `git-flow`.
- **Save as you go.** Every time they like something, commit it, in one line of their language. It costs nothing, and it is the only reason "it was better before" has an answer. Never push, never add a remote — this history is local and stays local.

## The skills here

Load them; they exist because the shortcut is usually wrong.

| Skill | When |
|---|---|
| `getting-set-up` | First session, or nothing starts |
| `git-flow` | Saving their work, showing them what changed, and undoing something. **After anything they liked, and before anything risky.** |
| `exploring-snowflake` | Finding a table, checking columns, previewing rows. **Before writing any query against real data.** |
| `building-a-dashboard` | Any "show me X" request — the whole path from question to screen |
| `checking-a-number` | "That total looks wrong", "this doesn't match my spreadsheet". **Investigate before you touch the query.** |
| `sharing-and-exporting` | "Can I get this in Excel?", "can I send this to my boss?" |
| `handing-off-to-engineering` | They're happy with it and want the platform team to build the real version |
| `pilgrims-look-and-feel` | Picking a component, laying out a page, anything about how it looks |
| `frontend-design`, `web-design-guidelines` | Deeper visual work when a screen needs to feel intentional |
| `fastapi` | Only if a page genuinely needs a new backend endpoint |
| `react-best-practices`, `typescript-expert`, `composition-patterns` | Reference. Mostly heavier than this kit needs — don't apply their production advice by default. |

## Two things the harness does for you

- **After you edit anything in `app/frontend`, a hook typechecks it.** If you get compiler output back, fix it before telling the person to look — a TypeScript error stops Vite rebuilding, so the browser is still showing the *previous* version and they will report that nothing happened.
- **At the start of every session you're told the state of the machine** — whether setup is done, what's uncommitted, and the last few things that were built. Use it instead of asking them what happened last time.

## When it breaks

Read `troubleshooting.md` before improvising — nearly every failure here is one of five things, and four of them are Snowflake login or role problems that look like code problems. A query that errors with "does not exist" is a grant issue far more often than a typo.
