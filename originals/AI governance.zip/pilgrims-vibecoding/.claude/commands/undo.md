---
description: Go back to an earlier version
argument-hint: "[what to undo, or how far back]"
---

Take them back, following the `git-flow` skill.

$ARGUMENTS is what they want undone. If it's empty or ambiguous, don't guess destructively — show them the recent versions as a plain dated list and ask which one they want, then restore it.

Rules that matter here: prefer `revert` and `restore`, never `reset --hard`, never `clean -fd` without showing what it would delete first, and say what is about to be thrown away before throwing it away.

Finish by telling them what the page looks like now, and that the version you just moved away from is still recoverable.
