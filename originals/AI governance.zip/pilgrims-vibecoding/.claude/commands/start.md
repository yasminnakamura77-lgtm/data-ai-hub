---
description: Start the app (and set it up if this is the first time)
---

Get the app running and open in the browser.

Use the `getting-set-up` skill if any of it isn't ready — missing tools, no git history, an empty `.env`, packages not installed. If it's all in place, just start both halves and check the Dashboard page actually fills in.

Do everything yourself; the person types nothing but answers. Finish with the URL and one line on what they can ask for next.
