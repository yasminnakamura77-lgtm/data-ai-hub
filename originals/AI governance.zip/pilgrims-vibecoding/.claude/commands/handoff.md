---
description: Package this prototype up for the engineering team to build for real
---

Follow the `handing-off-to-engineering` skill, start to finish.

Don't shortcut the two parts that make the package worth anything: derive the change set from git and **read every changed file**, and **re-run every query** to capture today's numbers as the acceptance check.

Then ask the person the business questions only they can answer — one message, nothing technical — and write it up. Anything they don't answer is an open question in the document, never a guess.
