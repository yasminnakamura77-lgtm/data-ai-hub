---
description: Save the current version so it can always be brought back
argument-hint: "[what to call this version]"
---

Save everything as it stands right now, following the `git-flow` skill.

If $ARGUMENTS is given, use it as the description of this version. Otherwise work out what changed since the last save and write the message yourself — one line, business language, no file or component names.

Then confirm in one sentence that it's saved and can be brought back. No SHAs, no branch names.
