---
description: A number looks wrong — work out whether the app or the source is wrong
argument-hint: "[which number, and what you expected]"
---

They think a figure is wrong: $ARGUMENTS

Follow the `checking-a-number` skill. Do not adjust the query to make the number match what they expected — find out which of the two is actually right first, then say so plainly, whichever way it falls.
