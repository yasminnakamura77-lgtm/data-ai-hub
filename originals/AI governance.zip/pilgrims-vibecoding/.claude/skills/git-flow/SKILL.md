---
name: git-flow
description: "Use to save, inspect or undo work in the vibecoding kit — after any change the person is happy with, at the start and end of a session, before replacing or deleting something they liked, and whenever they say \"go back\", \"that was better before\", \"I lost it\", \"undo that\" or \"did you keep the old version?\". Also covers first-time git setup on their machine. Local history only: no remote, no push, no pull request, ever."
risk: safe
source: internal
date_added: "2026-08-05"
---

# Git flow

The person you are working with will never type a git command and should never be shown one. **You run all of it, and you talk about it in their words: "saved", "I can bring that back", "here's what we changed on Monday."**

Git is here for exactly two reasons:

1. **Nothing they liked ever gets lost.** They cannot read a diff, so they cannot tell whether your last change broke the page they were happy with an hour ago. History is the only thing standing between "make it blue" and a lost afternoon.
2. **The handoff needs it.** When they hand this to engineering, the whole value of the package is "here is what changed and why" — see `handing-off-to-engineering`, which reads this history to write the design document.

**This repository is local only. There is no remote, no GitHub, no branch protection, no CI.** Never run `git push`, never `git remote add`, never offer to open a pull request, and never suggest they create a repo somewhere. Committing to their own machine is the entire workflow.

## First, is there a repo at all?

The kit ships as a zip and the zip does not carry `.git` — so **on most machines the first session starts with no history at all.** `getting-set-up` runs this, but check anyway at the start of any session:

```powershell
git status --short
```

`not a git repository` means set it up now, before touching a single file:

```powershell
git init -b main
git config user.name "<their name>"
git config user.email "<their JBS email>"
git add -A
git commit -m "Baseline: the vibecoding kit as shipped"
git tag kit-baseline
```

Notes on that block:

- **Set the identity locally, not `--global`.** You are on their machine and it may already be configured for something else. Their JBS email is already in `app/backend/.env` as `SNOWFLAKE_USER` if they've been set up — use it rather than asking again.
- **`kit-baseline` is the tag the handoff depends on.** It marks "untouched kit", which is what makes "everything this person built" a single answerable question later. Don't skip it, don't move it, don't delete it.
- If `git init -b main` errors on an old git, `git init` alone is fine — the branch name is irrelevant here.
- If `git` itself isn't installed: `winget install --id Git.Git` (Windows) or `brew install git` (Mac), then a **new terminal** before `git` resolves. If corporate policy blocks it, say so plainly — the kit still works, they just have no safety net, and they should know that.

If a repo already exists, don't re-init it. If it exists but has no `kit-baseline` tag, leave it — the handoff skill knows how to fall back to the first commit.

## The loop

**Commit every time the person reacts well to something.** "Yes, that's it", "nice", "leave that" — that is the signal. Don't wait for a milestone, don't batch a session's work into one commit, and don't ask permission to save. It costs nothing and it is the whole point.

```powershell
git add -A
git commit -m "Weekly broiler placements page, filtered by plant"
```

Then tell them in one clause: *"Saved that version — I can bring it back any time."* Not the SHA, not the branch, not the file list.

Commit at these moments specifically:

| Moment | Why |
|---|---|
| Right after they say they like something | This is the version they'll ask for back |
| **Before** you start something risky — a redesign, a rewrite of a page, a big query change | So there's a floor to fall to |
| **Before** you replace or delete anything they've seen | CLAUDE.md: ask before deleting their work. Committing first is how you can honour a "put it back" |
| End of a session | A crashed or closed session leaves dirty files, and next session's you won't know what they were |
| Just after `.env` is filled in and the connection proves out | Marks "setup done" as a distinct point |

### Write messages the person could read

The audience for these messages is the person, and later an engineer who has never seen this code. Business language, one line, no file names, no component names.

| Write this | Not this |
|---|---|
| `Volume by plant page, biggest plant first` | `add BarChart to dashboard.tsx` |
| `Yield KPI now excludes condemned birds` | `fix reduce in calcYield` |
| `Split sales page into this-year and last-year charts` | `refactor sales.tsx` |
| `Switched the date filter to ship date, not order date` | `change SHIP_DATE` |

That last one is worth noticing: **a change to a business definition is the most valuable thing a commit message can record**, because it is exactly what the handoff document has to explain and nothing else in the folder remembers it.

## Showing them where they are

When they ask what's been built, or you're picking up a session you didn't start:

```powershell
git log --pretty=format:"%ad  %s" --date=short -15
git status --short
```

Read the log to them as a plain list — dates and what changed. If `git status` shows uncommitted files, that's work from an interrupted session: tell them what those files are *about* (not their names), and commit them before starting anything new so they aren't tangled up with the next change.

## Undoing, in their language

They will say "go back", not "revert". Work out which of these they actually mean before running anything, and if it isn't obvious, ask — "back to how it looked when we started today, or just undo the last thing?" is a fair question.

| What they mean | Do this |
|---|---|
| "Undo what you just did" — not yet committed | `git restore <file>` for one file, `git restore .` for everything uncommitted. Say what's being thrown away first. |
| "The last change was wrong" — already committed | `git revert --no-edit HEAD`. Adds a new commit that puts things back; history stays intact. |
| "It was better before you touched the chart" | Restore just that one file from a good commit: `git checkout <sha> -- app/frontend/src/pages/volume.tsx` |
| "It worked yesterday" | `git log --pretty=format:"%ad %s" --date=short`, read it back to them, let them pick the moment, then revert or restore to it. |
| "Start over completely" | `git revert` back to `kit-baseline`, or a fresh copy of the kit. **Confirm first** — this is the one that throws away their afternoon. |

**Prefer `revert` and `restore` over anything that rewrites history.** Specifically:

- **Never `git reset --hard`.** It destroys uncommitted work silently, and the person has no idea what was uncommitted.
- **Never `git clean -fd`** without running `git clean -nd` first and telling them exactly what it will delete.
- **Never `git rebase`, `git commit --amend`, `git push --force`, or anything that rewrites a commit that already exists.** There's no remote to tidy for, so there is nothing to gain and a real chance of losing the one version they wanted.
- **Never `git checkout <sha>` bare** — a detached HEAD looks like nothing happened and then their next commit lands nowhere they can find. Add `-- <path>` and take the file, not the state.

## Branches: don't

One person, one machine, one line of history. Branches add a state the person cannot see and cannot reason about, and a session that ends on a forgotten branch makes the handoff wrong.

Work directly on `main` (or `master` — whichever the repo already has; don't rename it). If you genuinely need to try something throwaway, commit it on the line and revert if it's bad — that is what revert is for. **Never end a session on a branch that isn't the one you started on.**

## Rules

- **Never commit `.env`.** `.gitignore` covers it, and `make-zip.ps1` excludes it separately — but check `git status --short` before your **first** commit in a repo and confirm no `.env` and no `node_modules/` are listed. Snowflake credentials in a committed file will travel with the folder to whoever it's sent to next. If one has already been committed, say so directly rather than quietly fixing it.
- **`git add -A` is fine here.** `.gitignore` already excludes `node_modules/`, `dist/`, `.venv/`, `__pycache__/`, `.env` and `*.log`. Don't hand-pick files; a partial commit of a working page is worse than useless.
- **Commit the handoff artifacts too.** `handoff/` is normal content — it belongs in history like everything else.
- **`warning: LF will be replaced by CRLF`** is Windows noise. Ignore it, and don't mention it to them.
- **Don't narrate git.** No SHAs, no branch names, no "staged", no "HEAD". They asked for a chart.

## When a commit fails

| Error | Cause | Fix |
|---|---|---|
| `Author identity unknown` | No `user.name` / `user.email` | Set them locally, as in the setup block above |
| `nothing to commit, working tree clean` | Already saved, or you edited nothing | Not an error. Check you actually wrote the file you thought you wrote. |
| `fatal: not a git repository` | Fresh unzip, no history yet | Run the setup block, then commit |
| `git: command not found` | Git isn't installed | `winget install --id Git.Git`, then a new terminal |
| A huge commit, hundreds of files | `.gitignore` isn't being respected — usually because `node_modules` was committed before it existed | Say what happened, `git rm -r --cached node_modules`, commit that, and carry on |
