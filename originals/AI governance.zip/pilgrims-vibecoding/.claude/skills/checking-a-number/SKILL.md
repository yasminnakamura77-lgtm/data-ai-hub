---
name: checking-a-number
description: "Use when someone doubts a figure on a page — \"that total looks too high\", \"this doesn't match my spreadsheet\", \"we don't have that many plants\", \"last week can't be down 40%\", \"where does this number come from\", \"is this right?\". The ordered set of checks that finds the cause, and the rule that keeps you from making it worse: never adjust the query until you know which side is wrong."
risk: safe
source: internal
date_added: "2026-08-05"
---

# Checking a number

A blank page is obvious. **A number that is wrong but plausible is the dangerous failure**, because nothing looks broken and the person cannot audit it themselves. Their only signal is "that doesn't feel right", and they are usually reacting to real knowledge of their business. Take it seriously every time.

## The one rule

**Do not change the query until you know which side is wrong.**

The tempting move — adjust a filter, add an exclusion, switch a date column, until the total matches what they expected — turns a possibly-correct number into a permanently-wrong one, with no trace of what happened. If it later reaches the handoff document, it becomes a business rule an engineer will implement faithfully.

Also worth saying out loud: **a good share of the time the prototype is right and their spreadsheet is stale.** That is a genuinely useful finding, and you will only ever reach it if you investigate before you edit.

## Start by asking, not querying

Two questions, and they resolve this faster than any SQL:

1. **"What were you expecting, roughly?"** A total that's 3× out is a different bug from one that's 2% out. Off by a round multiple is almost always a join multiplying rows; off by a few percent is a filter or a period boundary; off by orders of magnitude is units or string arithmetic.
2. **"Where does your number come from?"** A spreadsheet, an MTech report, another dashboard, their own memory of last month. This gives you something to reconcile against, and it tells you whether their source and yours could even be measuring the same thing.

## Then read the query back in their language

Before touching anything, translate the query into a sentence and say it to them:

> This counts cases shipped, dated by ship date, for all plants, over the last 12 weeks, and it leaves out anything marked as a sample.

**Most disagreements end here.** They say "no — we count it when the order is placed", or "that includes the further-processing plants and my report doesn't", or "our week starts Sunday". That is the answer, it took one message, and it's a definition you now need to record.

## The checks, in the order they pay off

Work down. Each one is a real thing that has produced a wrong number in this warehouse.

**1. Grain.** `preview` the table and confirm what one row *is*. A table with one row per plant per day per SKU summed as though it were one row per plant per day double counts. If the grain doesn't match the question, everything downstream is noise.

**2. A join multiplying rows.** The classic. Snowflake accepts `PRIMARY KEY` declarations and never enforces them, so a column that looks unique can repeat — `MAPPING_TERRITORY_RSM.TERRITORY_CODE` is 95 rows and 38 distinct values. Symptom: the total is inflated by a suspiciously clean multiple.

```bash
uv run .claude/skills/exploring-snowflake/scripts/sf.py uniqueness DB.SCHEMA.TABLE JOIN_KEY
```

Compare `count(*)` before and after the join. If the row count moved, that's it.

**3. String arithmetic.** Snowflake returns decimals as JSON strings (`"80.6"`), so `sum + row.TOTAL` concatenates instead of adding. `src/ui` components and the `format*` helpers coerce; a `reduce` you wrote does not. Symptom: an absurd figure, or a number that is visibly two numbers stuck together. Bites hardest on averages, percentages and money — exactly where a wrong total is hardest to spot.

**4. Filters that exclude more than they look like they do.**

- Value mismatch: `where PLANT = 'Plant A'` against data that says `PLANT_A`, or values with trailing spaces. Returns fewer rows, successfully.
- `NULL`: `where STATUS != 'CANCELLED'` silently drops every row where `STATUS` is null. So does an inner join against a dimension with missing keys.
- A date column that is a `VARCHAR` compared against a date — sometimes works, sometimes silently matches nothing.

**5. Period boundaries.** Which day a week starts on, `current_date()` versus their "as of last night", a partial current week or month rendering as a cliff at the right edge of the chart, and timezone if the timestamps are UTC and the plant isn't. The last-bar cliff is reported as "volume collapsed" more often than any other false alarm.

**6. Duplicates in the source.** `count(*)` versus `count(distinct <business key>)`. Restated or re-loaded source rows are common in staging tables — another reason to prefer `MART_*` and gold.

**7. Units and scale.** Pounds vs cases vs eaches vs head, thousands, currency. Their report may be in a different unit and both numbers can be right.

**8. Are you even reading the right table?** `SALES` and `SALES_QA_10315` both contain a `MART_CIRCANA_SALES_PPC`, and `PILGRIMS` holds `DATAGOVERNANCE_SL_MDM` next to `_SL_DEV` and `_MDM_POC` with different row counts. Check what the query actually points at, and prefer gold over silver over bronze. See `exploring-snowflake`.

## Reconcile on one cell, not the total

If it's still unexplained, stop comparing headline totals — they hide compensating errors. Pick **one plant, one week** where they know the right answer, and query just that. Then walk out: same plant all weeks, then all plants that week. The dimension where the disagreement appears names the cause.

Show them the rows behind that one cell in the Explore tab. Being able to see the underlying records is what converts "I don't trust this" into "oh — that shipment shouldn't be in there".

## Then say which side was wrong

Plainly, either way:

- **The page was wrong.** Say what was wrong, what the number is now, and whether any other page shares the mistake — a definition usually appears in more than one query. Fix it, then commit with a message that records the *definition*, not the code: `Yield now excludes condemned birds` (see `git-flow`). That message is what carries the decision into the handoff.
- **The page was right.** Say so, show the working, and be careful — their spreadsheet may be something they built and rely on. Give them the evidence and let them draw the conclusion. This is a finding worth more than the dashboard.
- **Both are right, measuring different things.** The most common outcome of all. Name the difference precisely ("yours is order date, this is ship date"), then ask which one this page should use.

Either way, **the definition you just confirmed goes in the handoff document** as a business rule marked *confirmed* — section 4 of `handing-off-to-engineering`. A rule that survived an argument is the most valuable line in that document.

## Never

- **Never tune the query until it matches their expectation.** State the discrepancy; don't dissolve it.
- **Never round, cap, or format a discrepancy out of sight.**
- **Never blame the data without evidence.** "The source is probably wrong" is a conclusion, not a starting position — show the rows.
- **Never leave it unresolved and move on to the next request.** An unexplained number costs the trust of every other number on the screen.
