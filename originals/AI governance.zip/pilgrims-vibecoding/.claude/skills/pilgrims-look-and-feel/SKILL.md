---
name: pilgrims-look-and-feel
description: "Use when writing or restyling any UI in the vibecoding kit — picking a component, laying out a page, choosing colours, sizing a chart, or when someone says a screen looks wrong, cluttered, or unlike the real Control Tower apps. The full inventory of src/ui, the design tokens, and the rules that keep a prototype looking like the product."
---

# The look and feel

`app/frontend/src/ui` is a trimmed copy of `@pilgrims/ui`, the component library the real Control Tower apps are built from — same colours, same spacing, same components. **Building from it is the only reason a prototype from this kit looks like the real product.** A hand-rolled `<div className="rounded border p-4">` is what makes it look like a prototype.

Everything imports from one place:

```tsx
import { BarChart, ChartCard, DataTable, KpiCard, ReportGrid, ReportShell } from '@/ui';
```

## Page frame

| Component | Use |
|---|---|
| `ReportShell` | Every page's outer wrapper. `title`, optional `description`, optional `toolbar` for filters. |
| `ReportGrid` | Responsive grid, `columns={2 \| 3 \| 4}`. Collapses to one column on narrow screens. |
| `AppHeader` / `AppNav` / `AppNavLink` | Already wired in `App.tsx`. Add a page to the `PAGES` array; don't touch these. |

A page is a `ReportShell` containing a `ReportGrid` of KPI tiles, then grids of chart cards. Deviate when the content wants it, but that shape is the house style and it reads instantly.

## Cards

Three shapes, all taking `status` and `error` straight from a `useSql` result. That is what makes skeletons and error states appear — **never write a loading state by hand.**

```tsx
<KpiCard.Root status={sales.status} error={sales.error}>
  <KpiCard.Header icon={<Package />}>
    <KpiCard.Label>Total cases</KpiCard.Label>
  </KpiCard.Header>
  <KpiCard.Value>{formatCompact(total)}</KpiCard.Value>
  <KpiCard.Delta sentiment="good">+4.2% vs last week</KpiCard.Delta>
</KpiCard.Root>
```

- **`KpiCard`** — one number. `Label` (uppercase, small), `Value` (large, tabular), optional `Delta` with `sentiment="good" | "bad" | "neutral"`.
- **`ChartCard`** — a chart or table. `Header` (with optional `action` for a filter), `Title`, `Subtitle`, `Content`, `Footer`. `Content` carries the chart's minimum height and swaps in the skeleton and error states itself.
- **`Card`** — everything else. `Root`, `Header`, `Title`, `Subtitle`, `Content`, `Footer`.

To put a table inside a `ChartCard`, kill the padding: `<ChartCard.Content className="min-h-0 px-0">`.

## Charts

`LineChart`, `BarChart`, `DoughnutChart`. Each takes `labels` plus `series` and picks colours automatically.

```tsx
<LineChart area labels={weeks} series={[{ label: 'Cases', data: values }]} />
<BarChart horizontal labels={plants} series={[{ label: 'Cases', data: values }]} />
<BarChart stacked labels={weeks} series={[{ label: 'Fresh', data: a }, { label: 'Frozen', data: b }]} />
<DoughnutChart slices={[{ label: 'Retail', value: 62 }, { label: 'Food service', value: 38 }]} />
```

Choosing:

- **Line** for anything over time. `area` when there's one series and the volume matters more than the exact value.
- **Bar** for comparing categories. **`horizontal` whenever labels are names** — plants, customers, products. Rotated labels under a vertical bar chart are unreadable and are the single most common thing that makes a prototype look sloppy.
- **Stacked bar** for composition over time. **Doughnut** for composition at one moment, and only with a handful of slices.
- **A table** when the person will read individual values. Not everything wants to be a chart.

Fixed rules:

- **Colours must be literal.** Charts draw on a canvas where `var(--primary)` resolves to nothing — a chart styled with CSS variables renders invisible. Use the `CHART` palette (`CHART.primary`, `.green`, `.amber`, `.red`, …) or let the default `CATEGORICAL` order apply.
- **Height comes from the container.** `ChartCard.Content` supplies it. Pass `height={320}` for a taller chart; a chart in a bare div collapses to zero.
- **Eight categories, maximum.** `groupIntoOther(items, 7)` collapses the tail.
- Both themes are live. Grid lines and text already adapt — don't add a hardcoded white background or a black text colour.

## Tables

`DataTable` renders a `useSql` result directly, with its own loading, error and empty states.

```tsx
<DataTable result={sales} />

<DataTable
  result={sales}
  columns={[
    { key: 'PLANT', label: 'Plant' },
    { key: 'TOTAL', label: 'Cases', align: 'right', format: (v) => formatNumber(v) },
  ]}
/>
```

Numbers go `align: 'right'` — that also switches on tabular figures so digits line up. Always `format` them; a raw `1240000.0000` in a cell is the tell of an unfinished screen.

## Everything else

`Button` (`variant`: default, secondary, outline, ghost, link, destructive), `Select`, `Input`, `Label`, `Badge` (default, secondary, outline, success, warning, danger), `EmptyState`, `Skeleton`, `Spinner`, `ErrorMessage`, and the type scale `H1`, `H2`, `H3`, `Text`, `Muted`, `Footnote`.

Icons come from `lucide-react`, already installed: `import { Package, TrendingUp } from 'lucide-react'`.

If something genuinely isn't here, build it in the page file from Tailwind classes using the tokens below. Don't add a component library, and don't create an abstraction for a thing used once.

## Colours

Use the semantic token names, never raw Tailwind colours — `bg-red-500` breaks in dark mode, `bg-danger` doesn't.

| Token | For |
|---|---|
| `background` / `foreground` | Page |
| `surface` / `surface-muted` | Card and panel backgrounds |
| `border` | Every divider and outline |
| `muted-foreground` | Secondary text, labels, footnotes |
| `brand-600` / `brand-700` | Primary buttons and links |
| `brand-navy` / `brand-red` | Pilgrim's identity. The header rail only — not decoration. |
| `success` / `warning` / `danger` | Status only, never as a chart palette |

They live in `src/index.css`. Changing a value there restyles the whole app, which is the right way to answer "can it be less blue".

## Making it look considered

- **Whitespace over borders.** Cards are already separated by grid gaps; adding rules between them makes a page look busy.
- **Alignment beats decoration.** Numbers right-aligned, labels left, consistent card heights in a row.
- **One accent.** The palette is deliberately calm. A page where four things compete for attention has no emphasis at all.
- **Say what the number is.** "Cases shipped, last 12 weeks" as a subtitle removes more confusion than any styling.
- **Empty and loading states are part of the design.** They come free from `status`/`error` — passing them is the difference between a screen that looks finished and one that flashes blank.

For deeper visual work — typography, layout rhythm, making a screen feel intentional — the `frontend-design` and `web-design-guidelines` skills go further.
