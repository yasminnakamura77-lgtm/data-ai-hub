---
name: getting-set-up
description: "Use on a first session in the vibecoding kit, or when someone says they can't start the app, nothing happens, they don't know their Snowflake details, or a command isn't found. Covers checking and installing Node/pnpm/uv/git, starting local git history so their work can't be lost, filling in .env, starting both halves, and proving the Snowflake connection works before anything gets built."
---

# Getting set up

First run on a new machine. **Do all of this yourself** — the person should have to type nothing but answers. Report at the end in plain language.

## 1. Check what's installed

```powershell
node --version; pnpm --version; uv --version; git --version
```

Anything missing, install it and say what you're doing:

| Missing | Fix | Notes |
|---|---|---|
| `node` | Download the LTS installer from [nodejs.org](https://nodejs.org) | Needs a human to click through. Say so, wait, then re-check. |
| `pnpm` | `npm install -g pnpm` | Needs Node first. |
| `uv` | `winget install --id=astral-sh.uv` (Windows), `curl -LsSf https://astral.sh/uv/install.sh \| sh` (Mac) | Both may need a new terminal before `uv` resolves. |
| `git` | `winget install --id Git.Git` (Windows), `brew install git` (Mac) | Needs a new terminal after. Not optional — step 2 depends on it. |

If a corporate policy blocks an install, that's a real blocker — say so plainly rather than working around it.

## 2. Start the safety net

**Do this before anything gets built.** The kit arrives as a zip and the zip carries no history, so right now nothing they build can be recovered. Git is what makes "put the old chart back" answerable, and it's what the handoff to engineering reads later.

```powershell
git init -b main
git config user.name "<their name>"
git config user.email "<their JBS email>"
git add -A
git commit -m "Baseline: the vibecoding kit as shipped"
git tag kit-baseline
```

Don't spend a question on the name and email — fold them into the one message in step 3, or just use their JBS email for both fields now and move on. Set them locally like this, never `--global`: it's their machine and it may already be configured for something else.

If `.git` already exists, don't re-init — just check `git status --short` is clean and move on. Full rules, including what to do when they ask to undo something, are in `git-flow`. **Never add a remote and never push; this history lives on their machine only.**

Don't explain any of this to them. One sentence — *"I've turned on version history, so nothing you build can get lost"* — is the whole report.

## 3. Snowflake details

**Ask them for these values. Never invent one, and never leave one blank hoping it will work.** A missing `SNOWFLAKE_ACCOUNT` surfaces as `251001: Account must be specified` on the first query, which looks like a code bug and isn't — it means this step was skipped.

**Ask about the VPN in the same message.** Snowflake is only reachable from the JBS network, so if they are working from home they must be connected to the VPN before the first query. A VPN that is off usually shows up as a query that hangs and then times out, or `could not connect to Snowflake backend after 1 attempt`. That is not a wrong password and not a bad role — it is the network. Confirm the VPN is on before spending time on any other diagnosis.

Copy `app/backend/.env.example` to `app/backend/.env` if it isn't there. Then **you** write their answers into that file — with the Edit tool, not by telling them which line to change. They should never have to open `.env`. Read it back afterwards to confirm all four values are actually set, and remember the backend reloads on save, so no restart is needed.

3 values to ask for, in one message:

- **`SNOWFLAKE_ACCOUNT`** — the identifier from the Snowflake URL, not the whole URL. `https://ab12345.us-east-1.snowflakecomputing.com` → `ab12345.us-east-1`. Ask them to open Snowflake in a browser and read the address bar. Please do suggest: `JBSUSA-PROD`, as that's the one they'll likely pass. Just ask if that value is correct, then update .env. 
- **`SNOWFLAKE_USER`** — their JBS email.
- **`SNOWFLAKE_WAREHOUSE`** — should be `WH_PILGRIMS`. Just ask to confirm.

Leave `SNOWFLAKE_AUTHENTICATOR=externalbrowser`. That's the sign-in-with-your-JBS-account flow, and it's the right one.

## 4. Start it

`./start.ps1` (Windows) or `./start.sh` (Mac) handles the install and launches both halves. Or run them yourself: `uv run uvicorn main:app --reload --port 8000` in `app/backend`, `pnpm dev` in `app/frontend`.

The first `uv run` downloads Python packages — a minute or so, once.

## 5. Prove it works before building anything

Open http://localhost:5173. The Dashboard page runs on data Snowflake generates on the fly, so **it works without a single real table** — if those charts fill in, the whole chain is good: browser → frontend → backend → Snowflake.

The first query opens a Microsoft sign-in window. Tell them to expect it. It should happen **once** — repeatedly means the login cache is broken (see `troubleshooting.md`, item 1).

If the charts stay empty, read the error before touching anything: `Account must be specified` means a blank in `.env` (step 3), a hang or timeout means the VPN is off, and `does not exist` means the role.

Then confirm real access:

```bash
uv run .claude/skills/exploring-snowflake/scripts/sf.py databases
```

If that lists databases they recognise, they're ready. If it lists almost nothing, it's the role — go back to step 3.

## 6. Hand over

Commit first — `.env` is gitignored, so this saves the working setup and nothing secret:

```powershell
git add -A; git commit -m "Setup complete, Snowflake connection working"
```

Then tell them, in this order: it's running, here's the URL, here's what the two tabs do, their work is saved as they go and can always be brought back, and here's how to ask for the first real thing. Then ask what they want to see. Don't list the file structure and don't explain the code.
