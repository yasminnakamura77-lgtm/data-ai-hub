---
name: handing-off-to-engineering
description: "Use when a prototype built in the vibecoding kit is good enough to become a real product and needs to go to the platform team — \"hand this off\", \"send this to engineering\", \"who builds this for real\", \"make this production\", \"write this up for the developers\", \"I'm done, what now\". Turns local vibecoded changes the person cannot read into an implementation document an engineer can rebuild from: goals, screens, the actual SQL, the business rules hidden in the queries, what to keep, what to throw away, and what still needs deciding."
risk: safe
source: internal
date_added: "2026-08-05"
---

# Handing off to engineering

The prototype worked, the person wants it for real. **Your job is to translate a folder they cannot read into a document an engineer can build from — and then throw the folder away.**

Frame it that way for both audiences. To the person: *"I'm writing up what we built so the platform team can build the real version. I need to ask you a few things only you know."* To the engineer, in the document: **this prototype is a specification, not a codebase.** Expect it to be rewritten. Nothing in `app/` is meant to survive.

That is not a disclaimer — it's the actual design constraint of the document. An engineer reading it should never need to open a `.tsx` file to know what to build.

## Why this is worth doing properly

The prod Control Tower stack is close to this one — React + pnpm on the front, FastAPI on the back, Snowflake underneath — so nothing here is *hard* to migrate. But the parts that are hardest to recover are the parts that aren't code:

- **The business definitions baked into `where` clauses.** Which date column counts. Whether condemned birds are excluded. What a "case" is. The person decided these out loud, in chat, and the only surviving trace is a SQL string nobody will read.
- **Which table is the right one.** This account is full of QA clones and `_DEV` schemas that look identical to production (see `exploring-snowflake`). Somebody already did that work. Write down which object was chosen so it isn't re-litigated.
- **What the person actually wanted** versus what the prototype happened to do. A hardcoded 12-week window might be the requirement or might be a shortcut you took on a Tuesday. Only one of those should survive.

Lose those and the rewrite ships something that looks right and reports the wrong number.

## Before you write anything

### 1. Commit, then find the change set

Use `git-flow`. Commit everything outstanding first — a handoff that describes uncommitted work is a handoff that can't be reproduced.

Then get the real inventory. Do not work from memory or from this session's context; sessions get summarized and files get edited more times than you remember.

```powershell
git log --pretty=format:"%ad  %s" --date=short
git diff --stat kit-baseline..HEAD
git diff --name-status kit-baseline..HEAD
```

If `kit-baseline` doesn't exist, use the first commit instead:

```powershell
git rev-list --max-parents=0 HEAD
```

**Then read every file in that name-status list, start to finish.** Added pages, changed pages, changed `App.tsx`, anything in `lib/`, any new backend endpoint. The diff tells you where to look; it does not tell you what the page does.

### 2. Pull out every query, and run it

The SQL is the single most valuable thing in the package. Extract each query string verbatim — do not tidy it, reformat it, or "improve" it on the way out. An engineer needs to be able to paste it into Snowflake and get the same rows.

Run each one now, via the Explore tab or `sf.py query`, and record:

- **that it still works** (a query that errors today is a finding — say so in the document rather than shipping it as spec)
- **the current headline numbers**, with the date you ran them. This becomes the acceptance check: the rewrite is correct when it reproduces these figures.
- **the row count and shape**, so the engineer knows whether this is 40 rows or 4 million.

Also confirm the objects are the real ones with `sf.py find` / `columns`. If the prototype is reading `SALES_QA_10315`, that is a defect to flag loudly at the top of the document, not a detail.

### 3. Ask the person the things only they know

**One message, business language, no more than about eight questions, and never a technical one.** They cannot tell you whether to cache; they can tell you who reads this on a Monday morning.

Ask about:

- **The decision** — what do they do differently because of this screen? Who else looks at it?
- **How often it needs to be right** — live, hourly, this morning's numbers, last week's? This is the single question that most changes the engineering.
- **Who should be able to see it** — everyone, their team, plant managers only? Any plant or region someone shouldn't see?
- **What's still missing** — what did they want that we didn't get to? Say plainly it goes in as a wish, not a promise.
- **Which parts are load-bearing** — "if the engineers had to drop one of these three charts, which?" and "does the layout matter or just the numbers?"
- **The definitions you're unsure about** — read a rule back in their words and confirm it: *"the yield number leaves out condemned birds — is that right for everyone, or just for your team's version?"*
- **Whether today's numbers look right to them** — their sign-off on the figures is what makes the acceptance table meaningful.

Anything they don't answer becomes an **open question** in the document. Do not fill a gap with a plausible guess; an invented requirement is the one failure mode of this document that an engineer cannot detect.

### 4. Get pictures

Screenshots do more than any paragraph you can write, and you probably can't take them yourself. Ask the person directly:

> Press **Win+Shift+S**, drag over each page, and paste it into `handoff/screens/`. One per tab — name it after the tab.

Wait for them, and check the folder. A handoff with no screenshots is materially worse; don't quietly skip it.

## What you produce

Everything under `handoff/`, then committed:

```
handoff/
  HANDOFF.md          the document — see template.md in this skill folder
  changes.patch       git diff kit-baseline..HEAD
  history.bundle      full git history as one file (optional but cheap)
  queries/            one .sql file per report, exactly as run
  screens/            their screenshots
```

```powershell
mkdir handoff\queries, handoff\screens
git diff kit-baseline..HEAD > handoff\changes.patch
git bundle create handoff\history.bundle --all
```

**The patch and the bundle exist because git history does not travel in the zip** — `make-zip.ps1` excludes `.git` on purpose. Without them the engineer gets a folder with no way to tell kit from creation. With them they can `git clone handoff/history.bundle` and read every commit message.

Write `HANDOFF.md` from [template.md](template.md). Copy the structure; fill every section or say explicitly why one is empty.

## How to write it

**Write for an engineer who has never opened this kit.** They don't know what `useSql` is, they have never heard of `POST /api/query`, and they should not have to care. Describe behaviour, data and rules — not this codebase's idioms.

- **Separate requirement from artifact, in every section.** "Volume by plant, largest first" is the requirement. "A horizontal `BarChart` from `src/ui`" is an artifact of this kit. The first is binding; the second is a screenshot.
- **Label anything you inferred.** If the person never said the window should be 12 weeks and you picked it, mark it `[inferred — confirm]`. Be liberal with this. An engineer who knows which lines are soft will ask; one who can't tell will build all of it as gospel.
- **Quote the SQL in full.** In the document, not just in the folder. It is the deliverable.
- **Give the numbers, with a date.** "Total cases, last 12 weeks, as of 2026-08-05: 4,182,340." Vague ambition ("should match the warehouse") is not testable.
- **Say what to throw away as forcefully as what to keep.** The prototype does several things no production app should do; the list is below and it belongs in the document verbatim, not softened.
- **No code walkthroughs.** No "then in `dashboard.tsx` line 40". The file is going to be deleted.
- **Don't invent architecture for them.** You can say "this needs a real endpoint per report instead of arbitrary client SQL" — that's a constraint. Do not specify their service boundaries, their caching strategy, or their table design. That's their job and they're better at it.

## The prototype shortcuts that must not ship

Put this in the document plainly. Every one of these is deliberate here and wrong in production:

| In the prototype | Why it's there | What production needs |
|---|---|---|
| `POST /api/query` takes arbitrary SQL from the browser | One endpoint is all a prototype needs | A named endpoint per report; SQL lives on the server |
| Filter values interpolated into SQL strings | Reads are guarded, so it can't do damage here | Bound parameters |
| Read-only guard is keyword matching (`guard.py`) | Backstop behind Snowflake grants | Grants as the real control; no raw SQL path to guard |
| No authentication — anyone on the machine sees everything | It's one person's laptop | JBS SSO, and whatever row-level scoping the answers to "who can see this" imply |
| The person's own Snowflake role and cached SSO login | Their credentials, their machine | A service account with explicit grants — **this is usually the longest-lead item; flag it early** |
| Every query re-runs on render, no caching | Data volumes are small and it's one user | Whatever their standard is |
| Date windows and thresholds hardcoded in the SQL | Faster than building a control | Confirm each one is a requirement, then make it a parameter or a constant with a name |
| Ad-hoc SQL against marts | Nobody was going to model it in an afternoon | Likely a dbt model, if this becomes something people depend on |
| No tests, no error handling beyond a card that says "failed" | Prototype | Theirs |

## What maps across cleanly

Say this too — it's the reason the estimate isn't frightening. The stacks line up:

| This kit | Prod Control Tower | Migration |
|---|---|---|
| React + TypeScript + Vite, pnpm | React + TypeScript, pnpm | Page logic and chart shapes port nearly as-is |
| `src/ui` components | `@pilgrims/ui` | `src/ui` is a copy of it — same components, same tokens. Layout carries over. |
| FastAPI + `snowflake-connector-python` | FastAPI + Snowflake | Same libraries; what changes is the endpoint shape and auth |
| Snowflake marts, read-only | Same warehouse | Identical objects. The queries are the real reusable asset. |

The genuine engineering is auth, the service account and its grants, replacing the generic query endpoint with real ones, and productionising the data access. The screens themselves are close to free.

## Finish it

1. Commit `handoff/` with a message like `Handoff package for engineering`.
2. Run `.\make-zip.ps1` yourself. The handoff folder rides along inside it.
3. Tell the person, in plain language: what the zip is, where it is, who to send it to, and the one sentence to send with it — *"Read `handoff/HANDOFF.md` first; the prototype in `app/` is a spec, not code to keep."*
4. Tell them what you asked the engineers to decide — the open questions — because they will get asked about those in the first meeting and should not be surprised by them.
5. Point out that the prototype still works on their machine and they can keep changing it. A handoff is a snapshot, not a shutdown. If they keep going, the package needs regenerating.
