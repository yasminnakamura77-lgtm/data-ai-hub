# Template: handoff/HANDOFF.md

Copy this into `handoff/HANDOFF.md` and fill it in. Keep the section order — engineers will skim it in this order. Delete the `<!-- guidance -->` comments as you go. If a section genuinely doesn't apply, leave the heading and write one line saying why; a missing heading reads as an oversight.

---

# <Report name> — prototype handoff

**Built by:** <name>, <team> · **Written:** <date> · **Prototype:** vibecoding kit, local only

> **Read this before the code.** This folder contains a working prototype built by a business user with an AI agent, on their laptop, against production Snowflake reads. **It is a specification, not a codebase.** Expect to rewrite it. The parts that matter are the queries, the business rules in section 4, and the numbers in section 8 — not the React.

## 1. What this is and why it exists

<!-- Two or three sentences, from the person's answers, not from the code. The business question, the decision it supports, and what they do today instead. If they told you the current process is a spreadsheet someone emails on Mondays, say that — it's the strongest argument in the document. -->

**The decision it supports:** <what someone does differently because of this screen>
**Who reads it:** <roles, rough count>
**How often, and how fresh:** <daily / weekly / live — and how stale the data may be before it's useless>
**What it replaces:** <spreadsheet, manual query, nothing>

## 2. Goals and non-goals

**Goals** — what the rewrite must deliver:

1. <...>
2. <...>

**Non-goals** — explicitly out of scope, so nobody builds them:

- <...>

**Wishes** — asked for, not built, not promised. Sequence these with the team, not here:

- <...>

## 3. The screens

<!-- One subsection per page. Screenshot first — it does more work than the prose. Describe behaviour, never components. -->

### 3.1 <Page name>

![<page name>](screens/<file>.png)

**Purpose:** <one line>

**On the page:**

| Element | Shows | Notes |
|---|---|---|
| KPI tiles | <...> | <...> |
| Chart | <...>, <sorted how> | <...> |
| Table | <columns> | <...> |

**Filters:** <control, values, default, and where the values come from — a warehouse query or a fixed list>

**Interactions:** <what happens on change; any drilldown; anything deliberately not clickable>

**Query:** [`queries/<name>.sql`](queries/<name>.sql) — reproduced in section 5.

**Layout:** <does the arrangement matter, or only the content? Say which. `[inferred]` if you're guessing.>

## 4. Business rules and definitions

<!-- THE most important section, and the one that exists nowhere else. Every filter, exclusion, conversion and choice of column that encodes a business decision. Pull them out of the SQL and state them in business terms, with the reason. Mark anything the person didn't explicitly confirm. -->

| Rule | Where it applies | Why | Confirmed by the person? |
|---|---|---|---|
| Ship date, not order date, drives every period | all charts | <reason they gave> | yes |
| Condemned birds excluded from yield | yield KPI | <...> | yes |
| Weeks start Monday | weekly trend | <...> | `[inferred — confirm]` |
| Last 12 weeks | all charts | <requirement, or a shortcut?> | `[inferred — confirm]` |

**Definitions:** <term> = <precise meaning, including units and currency>

## 5. Data

**Everything below is read-only. The prototype has no write path and neither should the product** — warehouse changes go through the MDM platform.

| Object | Grain | Used for | Notes |
|---|---|---|---|
| `DB.SCHEMA.TABLE` | one row per <...> | <...> | <row count and date; gold/silver; prod-vs-clone confirmation> |

**Chosen deliberately:** <if there were look-alike candidates — QA clones, `_DEV` schemas, a `_BZ`/`_SL`/`_GD` choice — say which was picked and why. This saves the engineer the same investigation.>

**Access:** the prototype ran as `<role>` using the person's SSO login. **Production needs a service account with equivalent grants — expect this to be the longest-lead item.**

**Gotchas found while building** — real, cost real time here:

- <e.g. `PLANT_NAME` has trailing whitespace in ~200 rows>
- <e.g. decimals arrive as JSON strings from the Snowflake connector; naive addition concatenates>
- <e.g. `TERRITORY_CODE` is not unique — 95 rows, 38 distinct — joins multiply rows>
- <e.g. `SHIP_DATE` is a VARCHAR, not a DATE>

### The queries, verbatim

<!-- Full text, exactly as run. Do not reformat. Also in queries/. -->

**<Report name>** — returns <n> rows, one per <...>:

```sql
select ...
```

## 6. What must survive the rewrite

<!-- The requirement, stripped of this kit. If an engineer changes only these things, they've broken it. -->

- The numbers in section 8 must reproduce exactly.
- Every rule in section 4 marked *confirmed*.
- <the filters that are actually used vs. the ones that were nice to have>
- <...>

## 7. What must **not** survive

<!-- Copy the shortcut table from the skill, trimmed to what this prototype actually does. Blunt. -->

| In the prototype | Why it's there | Production needs |
|---|---|---|
| `POST /api/query` accepts arbitrary SQL from the browser | one endpoint is all a prototype needs | a named endpoint per report; SQL server-side |
| Filter values interpolated into SQL | reads only, single user | bound parameters |
| No authentication | one laptop | JBS SSO + <the visibility answer from section 1> |
| The person's own Snowflake role and cached SSO login | their machine | service account with explicit grants |
| Hardcoded <window/threshold> | faster than a control | confirm it's a requirement, then name it |
| No caching — every query re-runs on render | small volumes, one user | your standard |
| Ad-hoc SQL against marts | nobody was modelling in an afternoon | likely a dbt model |
| No tests, no real error handling | prototype | yours |

## 8. Acceptance — the numbers to match

Run against production on **<date>**, as role `<role>`, and confirmed as plausible by <name>.

| Figure | Value | How to reproduce |
|---|---|---|
| <Total cases, last 12 weeks> | <4,182,340> | `queries/<name>.sql` |
| <Plants reporting> | <17> | ditto |
| <Top plant by volume> | <name, value> | ditto |

<!-- Say if a figure moves with the date, and what's stable about it (ranking, ratio) if the absolute number isn't. -->

## 9. Open questions

<!-- Everything the person couldn't answer or you couldn't determine. Never resolve one with a guess — an invented requirement is undetectable downstream. Name the owner if you know it. -->

| Question | Why it matters | Who can answer |
|---|---|---|
| <...> | <what it blocks> | <...> |

## 10. Migration notes

The stacks line up, which is why this is mostly effort and not risk:

| Prototype | Prod Control Tower | Migration |
|---|---|---|
| React + TS + Vite, pnpm | React + TS, pnpm | page logic and chart shapes port nearly as-is |
| `src/ui` | `@pilgrims/ui` | `src/ui` is a copy — same components and tokens, layout carries over |
| FastAPI + `snowflake-connector-python` | FastAPI + Snowflake | same libraries; endpoint shape and auth change |
| Snowflake marts, read-only | same warehouse | identical objects; the queries are the reusable asset |

Real engineering sits in: auth, the service account and grants, replacing the generic query endpoint, and productionising data access. The screens are close to free.

## 11. What's in this folder

| Path | What it is |
|---|---|
| `HANDOFF.md` | this document |
| `changes.patch` | everything built on top of the stock kit (`git diff kit-baseline..HEAD`) |
| `history.bundle` | full local git history — `git clone history.bundle` to read the commit-by-commit story |
| `queries/` | the SQL, exactly as run |
| `screens/` | screenshots of each page |
| `../app/` | the running prototype. Spec, not code to keep. |

**To run it yourself:** install Node, pnpm and uv; fill `app/backend/.env` with your own Snowflake account, user and warehouse; `./start.ps1`; open http://localhost:5173. Needs the JBS VPN. `README.md` and `troubleshooting.md` at the root cover the rest.
