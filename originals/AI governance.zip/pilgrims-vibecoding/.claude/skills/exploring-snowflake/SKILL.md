---
name: exploring-snowflake
description: "Use when exploring, querying, or answering questions about the JBS Snowflake warehouse directly from Claude Code — finding which database or table holds something, inspecting columns, previewing rows, checking whether a candidate key is really unique, or tracing where a mapping's data actually lives. Read-only. Covers the account's non-production noise (QA clones, dbt sandboxes) that makes naive listings wrong, and the role/SSO setup that makes tables look absent when they are not."
risk: safe
source: internal
date_added: "2026-08-04"
---

# Exploring Snowflake

Direct read-only access to the JBS Snowflake account, with no backend involved. **This is how you find out what data exists before building a page on top of it.** Use `scripts/sf.py` rather than hand-writing connector code each time — it carries the read-only guard, the output caps, and the non-production filtering described below, all of which exist because their absence produced a specific wrong answer.

```bash
uv run .claude/skills/exploring-snowflake/scripts/sf.py whoami
```

Run it from the kit root. `uv` resolves the dependencies from the script's inline PEP 723 block into a cached environment on first run (a few seconds), then reuses it — nothing to install, no virtualenv to activate. It reads `app/backend/.env`, so it shares the app's credentials and its cached SSO login.

## The three rules that matter most

**1. Never report a QA clone or a sandbox as where data lives.** This account is littered with non-production databases and they are not marked as such by anything except their names. `SALES`, `SALES_QA_10315`, `SALES_QA_10365`, `SALES_QA_9334` all contain a `MART_CIRCANA_SALES_PPC`. A naive "find this table" returns four hits that look equally authoritative, and picking the wrong one means quoting row counts and schemas from somebody's ticket branch. `sf.py` excludes them from `databases` and `find` by default and prints what it hid. **Do not defeat that filter to make an answer look more complete, and do not list QA databases in a summary** unless the request was specifically about QA. If you explicitly name one, the script prints a `NOTE:` line saying so — carry that caveat into whatever you report.

The two categories it filters:

| Pattern | What it is | Examples |
|---|---|---|
| `<BASE>_QA_<ticket>` | Per-ticket QA clone of a real database | `SALES_QA_10315`, `LEGACY_PPC_QA_9334`, `CORE_COMMON_QA_10359`, `LIVE_OPERATIONS_QA_10359` |
| `DBT`, `DATAIKU` | Whole databases of personal scratch space | `DBT` holds ~200 `DBT_<person>_*` schemas and 8,320 objects |

Two things the script does **not** filter, because their status is a judgement call rather than a naming convention — treat them with the same suspicion and say which you used:

- **`_DEV` / `_POC` schemas inside a production database.** `PILGRIMS` contains `DATAGOVERNANCE_SL_MDM` (32 tables), `DATAGOVERNANCE_SL_DEV` (68), and `DATAGOVERNANCE_MDM_POC` (33) side by side, all holding a `MAPPING_TERRITORY_RSM` with slightly different row counts (95 / 98 / 95). The `_MDM` pair is the one the MDM platform is about; the others are not.
- **`SRC_*_FVT` databases.** `SRC_EXTERNAL_FVT`, `SRC_INTERNAL_FVT`, `SRC_SAP_FVT`, `SRC_SHAREPOINT_FVT` sit beside non-`_FVT` versions and are plausibly another non-prod tier, but nobody has confirmed what `FVT` denotes here. Ask rather than assume, and don't silently prefer one.

**2. Aggregate before you list.** `information_schema` queries are cheap; dumping their results into a conversation is not. `tables DBT` would be 8,320 rows, and an early version of this exploration put 2,432 lines into a context window to answer "which tables do we have". Every listing command caps at `--max-rows` (default 100) and a listing that would exceed it **degrades into a schema-level summary telling you how to narrow**, rather than truncating silently — silent truncation reads as "this is all of it". Go `databases` → `schemas <DB>` → `tables <DB> --schema <S>`, and use `find` instead of listing a database you are guessing about.

**3. A missing table may be a missing grant.** Everything is filtered by the current role's privileges, silently. If `SNOWFLAKE_ROLE` is unset you land on `PUBLIC`, which sees a fraction of the account. Run `whoami` first: it prints the current role *and* every role granted to the user, then tells you to retry with `--role` before concluding something is absent. As of this writing `FFERNAN7@JBSSA.COM` defaults to `PUBLIC` but also holds `SFK_DEV_PILGRIMS`. "I could not find that table" is only a real answer once you have tried the roles you have.

## Commands

```bash
S=".claude/skills/exploring-snowflake/scripts/sf.py"

uv run $S whoami                                    # account, user, role, warehouse + granted roles
uv run $S databases                                 # visible databases, non-prod hidden and named
uv run $S schemas PILGRIMS                          # per-schema object counts. Do this before `tables`
uv run $S tables PILGRIMS --schema DATAGOVERNANCE_SL_MDM
uv run $S tables PILGRIMS --like 'MAPPING_%' --tables-only
uv run $S columns PILGRIMS.DATAGOVERNANCE_SL_MDM.MAPPING_TERRITORY_RSM
uv run $S preview PILGRIMS.DATAGOVERNANCE_SL_MDM.MAPPING_TERRITORY_RSM -n 10
uv run $S find MAPPING_TERRITORY_RSM                # search table names across all prod databases
uv run $S find 'LOV_%' --database PILGRIMS
uv run $S uniqueness PILGRIMS.DATAGOVERNANCE_SL_MDM.MAPPING_TERRITORY_RSM TERRITORY_CODE
uv run $S query "select count(*) from PILGRIMS.DATAGOVERNANCE_SL_MDM.MAPPING_PRODUCT_CATEGORY"
```

Global flags: `--role`, `--warehouse`, `--format table|csv|json`, `--max-rows N`, `--force` (print past the cap), `--include-nonprod`, `--env-file`.

`--format json` is the one to use when you need to feed values into something else — it emits real `null`, where the table format prints `NULL`. In the table format `NULL`, `''` and a literal `-` are rendered as three distinct things on purpose: this workspace's central MDM invariant is that unmapped, explicit N/A and a real value must never collapse into each other, and a display placeholder that could also be real data breaks that at the last step. 19 NULLs and 19 rows containing `"-"` are not the same finding.

## Read-only, and what that does and does not guarantee

`sf.py` refuses anything that is not a single read statement: leading keyword must be one of `select|with|show|describe|desc|explain`, no `;`-chained second statement, no mutating or session-tampering keyword anywhere outside a string literal. It is the same guard as `app/backend/guard.py`, kept as a separate copy so this script stands alone.

This is defense in depth, not the actual guarantee. **What a session can really do is decided by its Snowflake role's grants.** The guard stops a malformed or injected statement from becoming a write path; it does not make a write-capable role safe. Treat it as a seatbelt, and never relax it to "just run one small update" — there is no write path in this skill by design, and adding one is a different conversation.

## Authentication

**Two prerequisites before any of this connects, and both need the person, not you:**

1. **The VPN must be on.** Snowflake is only reachable from the JBS network. Off the VPN, a command hangs and then times out — it does not say "VPN". Ask them to confirm they are connected before you start diagnosing roles or grants.
2. **`app/backend/.env` must be filled in.** A blank `SNOWFLAKE_ACCOUNT` fails with `251001: Account must be specified`. Ask them for the values and write them into `.env` yourself.

Credentials come from the environment, falling back to `app/backend/.env` (override with `--env-file`). Precedence matches the app's own connector so a login in either place is interchangeable: **key-pair (`SNOWFLAKE_PRIVATE_KEY_PATH`, never prompts) > `externalbrowser` SSO (interactive) > `SNOWFLAKE_PASSWORD`**.

The current setup is `SNOWFLAKE_AUTHENTICATOR=externalbrowser`, so the *first* connect on a cold cache opens a browser for Microsoft SSO and waits on a human. Subsequent runs are silent: the script sets `client_store_temporary_credential=True` and declares the connector's `secure-local-storage` extra, which caches the id token in the OS keyring. **Without that extra the connector caches nothing and prompts on every single invocation** — if you find yourself getting a browser window per command, that is the cause, not a session problem. For headless or scheduled use, key-pair auth is the answer.

Practical consequence: **do not fire many `sf.py` calls in parallel on a cold cache.** Each would open its own browser window. Warm the cache with one `whoami`, then parallelise freely.

## What is actually in this account

Verified 2026-08-04 as role `PUBLIC` — a broader role will see more, and none of these counts are stable over time. Recheck rather than quoting this as current.

| Database | Objects | What it holds |
|---|---|---|
| `PILGRIMS` | 990 | The medallion layers (`*_BZ`/`*_SL`/`*_GD` = bronze/silver/gold) plus `DATAGOVERNANCE_*` — **including the existing MDM mapping and LoV tables** |
| `PILGRIMS_PROD` | 86 | `INT` (76 `INT_*` tables mirroring MTech modules) + `LIVE` (10, `D_`/`F_`/`VW_` convention) |
| `SALES` | 323 | `STAGING_*` → `INTERMEDIATE_*` → `MART_*_SALES_PPC` |
| `LIVE_OPERATIONS` | 249 | `MART_BROILER`, `MART_BREEDER`, `MART_HATCHERY`, `MART_FEED_MILL`, `MART_CORE`, `STAGING_MTECH_*` |
| `CORE_COMMON` | 119 | Cross-domain staging + `MART_SERVICEDESK`, `MART_HASHDATA` |
| `MTECHPOULTRY`, `MTECHPOULTRY_LEGACY` | ~1,520 each | One `MTP` schema each, raw MTech |
| `SRC_EXTERNAL`, `SRC_INTERNAL`, `SRC_SAP` | 1,774 / 115 / 30 | Raw source landing |
| `LEGACY_PPC`, `LEGACY_IT` | 228 / 122 | Legacy |
| `HRCORP`, `360LEARNING_BZ`, `FEDBEEF` | 18 / 44 / 0 to `PUBLIC` | HR and other domains |
| `EXT_SH_*`, `SH_*` | 2–9 | Inbound shares |

Largest tables worth not `SELECT *`-ing: `PILGRIMS_PROD.INT.INT_PROTEINSURVEYCOLLECTRESPONSEDETAILS` (105M rows, 7.6 GB) and `..._DETAILANSWERS` (64.9M rows, 4.8 GB). Use `preview -n`, and prefer `information_schema.tables.row_count` over `count(*)` — it is metadata and costs no warehouse time.

### Reading the naming conventions

Most of what a report wants sits in a `MART_*` schema — those are the modelled, business-facing tables, and they are the right place to start. `STAGING_*` and `INTERMEDIATE_*` are steps on the way there and usually have a grain nobody wants to chart.

In `PILGRIMS`, the medallion suffixes tell you the same thing: `*_BZ` bronze (raw), `*_SL` silver (cleaned), `*_GD` gold (business-ready). Prefer gold, then silver.

Column prefixes in the marts: `F_` fact tables (the numbers, one row per event), `D_` dimensions (the names and attributes you join to), `VW_` views. A chart almost always aggregates an `F_` and labels it from a `D_`.

Master data — the mapping and list-of-value tables the MDM platform edits — lives in `PILGRIMS.DATAGOVERNANCE_SL_MDM` (32 tables) and `PILGRIMS.DATAGOVERNANCE_GD_MDM` (15). Useful here as a *lookup* (what a code means, which territory an RSM owns), read-only like everything else.

### Before charting a table you just found

- **`preview` it.** Five rows tells you the grain, whether dates are dates or strings, and whether names have padding. All three change the query.
- **Check the grain matches the question.** "Volume by plant" against a table with one row per plant per day per SKU needs a `sum` and a `group by`, and getting that wrong produces a chart that looks fine and is wrong.
- **`uniqueness` when joining.** Snowflake accepts `PRIMARY KEY` declarations and never enforces them, so a column that looks like a key can repeat — `MAPPING_TERRITORY_RSM.TERRITORY_CODE` is 95 rows and 38 distinct values. Join on a non-unique key and rows multiply silently.

## Limitations

- **Read-only, deliberately.** No writes, no DDL, no `COPY`/`PUT`. Nothing in this kit writes to the warehouse, and that is not a gap to fill.
- **Everything is role-filtered and time-sensitive.** Object counts, row counts and the database list in this file are a 2026-08-04 snapshot taken as `PUBLIC`. Re-run rather than quoting them as current, and say which role produced a finding.
- **`row_count` and `bytes` from `information_schema` are metadata**, maintained by Snowflake and not transactionally exact. Fine for "is this big", not for reporting a figure to a person as the count.
- **Views report `row_count` as NULL**, which the table format shows as `NULL` — that means "not applicable", not "empty".
- **The read-only guard is keyword-based**, not a SQL parser. It is a backstop behind Snowflake grants, not a substitute for them.
- **`find` scans one `information_schema` per database serially**, so a full-account search is ~20 round trips. Narrow with `--database` when you already know roughly where to look.
