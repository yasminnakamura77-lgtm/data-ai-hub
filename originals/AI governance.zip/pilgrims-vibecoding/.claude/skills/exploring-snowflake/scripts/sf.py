#!/usr/bin/env python
# /// script
# requires-python = ">=3.11,<3.14"
# dependencies = ["snowflake-connector-python[secure-local-storage]>=3.12"]
# ///
"""Read-only Snowflake CLI for agent-driven exploration of the JBS warehouse.

Standalone by design: run it with `uv run sf.py ...` and uv resolves the
dependencies above into a cached env. It imports nothing from the app and does
not need its .venv. It reads credentials from app/backend/.env if nothing else
is configured, so one login covers both the app and this script.

Two things this exists to prevent, both learned the hard way:

- **Context floods.** `DBT` alone holds 8,320 objects across ~200 per-developer
  dbt sandbox schemas. A bare "list the tables" against the wrong database
  produces thousands of lines of noise. Every listing here is capped, and a
  listing that would exceed its cap degrades into a schema-level summary that
  tells you how to narrow it, rather than truncating silently.
- **Accidental writes.** `assert_read_only` refuses anything that isn't a single
  read statement. This is defense in depth, not the real guarantee: what a
  session can actually do is decided by its Snowflake role's grants. It exists
  so a malformed or injected statement cannot become a write path.

Credential precedence matches the backend's own connector so that a login here
and a login there are interchangeable and share one cached SSO token:
key-pair > externalbrowser SSO > password.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

import snowflake.connector

# Warehouse data contains accented names (PROTEINCITIES, vendor and customer
# tables). On a Windows console stdout defaults to cp1252, where printing one of
# those raises UnicodeEncodeError and kills the run partway through its output.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):  # already wrapped, or not a real stream
        pass

# ---------------------------------------------------------------------------
# Read-only guard
# ---------------------------------------------------------------------------

ALLOWED_LEADING_KEYWORDS = {"select", "with", "show", "describe", "desc", "explain"}

FORBIDDEN_KEYWORDS = re.compile(
    r"\b(insert|update|delete|merge|truncate|create|drop|alter|grant|revoke"
    r"|call|copy|put|remove|undrop|use|set|unset|execute|begin|commit|rollback)\b",
    re.IGNORECASE,
)

_LINE_COMMENT = re.compile(r"--[^\n]*|//[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_STRING_LITERAL = re.compile(r"'(?:[^']|'')*'")


class UnsafeSqlError(ValueError):
    pass


def assert_read_only(sql: str) -> None:
    """Raise UnsafeSqlError unless sql is a single read-only statement.

    Mirrors pilgrims-backend-services/app/modules/data/guard.py deliberately
    rather than importing it: this script must run with that repo absent. If the
    two ever diverge, the backend's copy is the one that gates the API.
    """
    stripped = _BLOCK_COMMENT.sub(" ", _LINE_COMMENT.sub(" ", sql)).strip()
    if not stripped:
        raise UnsafeSqlError("Empty query")

    if stripped.rstrip(";").count(";") > 0:
        raise UnsafeSqlError("Multiple statements are not allowed")

    leading = stripped.split(None, 1)[0].lower()
    if leading not in ALLOWED_LEADING_KEYWORDS:
        raise UnsafeSqlError(f"Only read statements are allowed (got '{leading}')")

    scannable = _STRING_LITERAL.sub("''", stripped)
    match = FORBIDDEN_KEYWORDS.search(scannable)
    if match:
        raise UnsafeSqlError(f"Forbidden keyword in query: {match.group(0).upper()}")


# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------

# Walk up from .claude/skills/exploring-snowflake/scripts/ to the kit root, so
# this shares the one set of credentials the app already uses.
_KIT_ROOT = Path(__file__).resolve().parents[4]
_DEFAULT_ENV_FILE = _KIT_ROOT / "app" / "backend" / ".env"

_ENV_KEYS = (
    "SNOWFLAKE_ACCOUNT",
    "SNOWFLAKE_USER",
    "SNOWFLAKE_ROLE",
    "SNOWFLAKE_WAREHOUSE",
    "SNOWFLAKE_DATABASE",
    "SNOWFLAKE_SCHEMA",
    "SNOWFLAKE_AUTHENTICATOR",
    "SNOWFLAKE_PASSWORD",
    "SNOWFLAKE_PRIVATE_KEY_PATH",
)


def _parse_env_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw = line.partition("=")
        key = key.strip()
        if key not in _ENV_KEYS:
            continue
        value = raw.strip().strip('"').strip("'")
        if value:
            values[key] = value
    return values


def _settings(args: argparse.Namespace) -> dict[str, str]:
    """Real environment wins; the backend's .env fills the gaps."""
    env_file = Path(args.env_file) if args.env_file else _DEFAULT_ENV_FILE
    merged = _parse_env_file(env_file)
    for key in _ENV_KEYS:
        if os.environ.get(key):
            merged[key] = os.environ[key]
    if args.role:
        merged["SNOWFLAKE_ROLE"] = args.role
    if args.warehouse:
        merged["SNOWFLAKE_WAREHOUSE"] = args.warehouse
    return merged


def connect(args: argparse.Namespace) -> snowflake.connector.SnowflakeConnection:
    cfg = _settings(args)
    if not cfg.get("SNOWFLAKE_ACCOUNT"):
        raise SystemExit(
            "No SNOWFLAKE_ACCOUNT configured. Set it in the environment, or pass "
            "--env-file pointing at a file that defines it (default: "
            f"{_DEFAULT_ENV_FILE})."
        )

    kwargs: dict[str, object] = {
        "account": cfg["SNOWFLAKE_ACCOUNT"],
        # Keeps the session alive so a run does not re-login mid-exploration, and
        # caches the SSO id token in the OS keyring so subsequent *processes*
        # reuse it. Without the secure-local-storage extra declared above, the
        # connector caches nothing and silently prompts every time.
        "client_session_keep_alive": True,
        "client_store_temporary_credential": True,
        "login_timeout": args.login_timeout,
        "network_timeout": args.network_timeout,
    }
    for key, kwarg in (
        ("SNOWFLAKE_USER", "user"),
        ("SNOWFLAKE_ROLE", "role"),
        ("SNOWFLAKE_WAREHOUSE", "warehouse"),
        ("SNOWFLAKE_DATABASE", "database"),
        ("SNOWFLAKE_SCHEMA", "schema"),
    ):
        if cfg.get(key):
            kwargs[kwarg] = cfg[key]

    # Precedence: key-pair (headless, never prompts) > externalbrowser SSO
    # (interactive, needs a real browser) > password (many SSO-federated
    # accounts reject it outright).
    if cfg.get("SNOWFLAKE_PRIVATE_KEY_PATH"):
        kwargs["private_key_file"] = cfg["SNOWFLAKE_PRIVATE_KEY_PATH"]
    elif cfg.get("SNOWFLAKE_AUTHENTICATOR", "").lower() == "externalbrowser":
        kwargs["authenticator"] = "externalbrowser"
    elif cfg.get("SNOWFLAKE_PASSWORD"):
        kwargs["password"] = cfg["SNOWFLAKE_PASSWORD"]
    else:
        raise SystemExit(
            "No Snowflake auth method configured: set SNOWFLAKE_PRIVATE_KEY_PATH, "
            "SNOWFLAKE_AUTHENTICATOR=externalbrowser, or SNOWFLAKE_PASSWORD."
        )

    return snowflake.connector.connect(**kwargs)


# ---------------------------------------------------------------------------
# Query + output
# ---------------------------------------------------------------------------


def run(con, sql: str, guard: bool = True) -> tuple[list[str], list[tuple]]:
    if guard:
        assert_read_only(sql)
    with con.cursor() as cur:
        cur.execute(sql)
        columns = [d[0] for d in cur.description]
        return columns, cur.fetchall()


def _fmt(value: object) -> str:
    """Render a cell unambiguously.

    NULL, empty string and a literal "-" are three different values, and this
    workspace's whole MDM premise is that states like those must not collapse
    into each other on the way to a human. A placeholder that could also be real
    data is how you end up mistaking 19 NULLs for 19 rows containing "-".
    """
    if value is None:
        return "NULL"
    text = str(value)
    if text == "":
        return "''"
    return text.replace("\n", "\\n").replace("\t", "\\t")


def emit(columns: list[str], rows: list[tuple], fmt: str, max_width: int = 60) -> None:
    if not rows:
        print("(no rows)")
        return

    if fmt == "csv":
        import csv

        writer = csv.writer(sys.stdout, lineterminator="\n")
        writer.writerow(columns)
        writer.writerows([[_fmt(v) for v in row] for row in rows])
        return

    if fmt == "json":
        import json

        # Not _fmt here: JSON has a real null, so use it rather than the string
        # "NULL". default=str covers dates, decimals and binary.
        print(json.dumps([dict(zip(columns, row)) for row in rows], indent=2, default=str))
        return

    cells = [[_fmt(v) for v in row] for row in rows]
    widths = [
        min(max_width, max(len(columns[i]), *(len(row[i]) for row in cells)))
        for i in range(len(columns))
    ]
    print("  ".join(c[:w].ljust(w) for c, w in zip(columns, widths)))
    print("  ".join("-" * w for w in widths))
    for row in cells:
        print("  ".join(c[:w].ljust(w) for c, w in zip(row, widths)))


# QA clones are named <BASE>_QA_<ticket>, e.g. SALES_QA_10315, LEGACY_PPC_QA_9334,
# LIVE_OPERATIONS_QA_10359. They are scattered through the account, there are
# several per base database, and their contents duplicate the real one closely
# enough that including them makes every cross-database search look like it found
# four of everything.
_QA_PATTERN = re.compile(r"_QA(_|$)", re.IGNORECASE)

# Whole databases that exist as personal scratch space rather than as anybody's
# source of truth: DBT holds ~200 per-developer dbt sandbox schemas (8,000+
# objects), DATAIKU the equivalent for Dataiku. A table found here is somebody's
# work in progress and is never the answer to "where does this data live".
_SANDBOX_DATABASES = {"DBT", "DATAIKU"}


def _is_qa(name: str) -> bool:
    return bool(_QA_PATTERN.search(name))


def _is_sandbox(name: str) -> bool:
    return name.upper() in _SANDBOX_DATABASES


def _nonprod_reason(name: str) -> str | None:
    """Why this database should stay out of discovery, or None to keep it."""
    if _is_qa(name):
        return "QA clone"
    if _is_sandbox(name):
        return "developer sandbox"
    return None


def _drop_internal(names: list[str]) -> list[str]:
    """Account-scoped and per-user databases, never interesting to explore."""
    return [n for n in names if not n.startswith(("SNOWFLAKE$", "USER$")) and n != "SNOWFLAKE"]


def _quote(identifier: str) -> str:
    """Quote an identifier for interpolation, rejecting embedded quotes.

    Object names come from the caller, so they cannot be bound as parameters —
    Snowflake has no placeholder for an identifier. Rejecting `"` is what keeps
    that from being an injection point.
    """
    if '"' in identifier:
        raise SystemExit(f"Refusing identifier containing a double quote: {identifier!r}")
    return f'"{identifier}"'


def _split_object(ref: str) -> tuple[str, str, str]:
    parts = [p.strip('"') for p in ref.split(".")]
    if len(parts) != 3:
        raise SystemExit(f"Expected DATABASE.SCHEMA.TABLE, got {ref!r}")
    _warn_if_qa(parts[0])
    return parts[0], parts[1], parts[2]


def _literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_whoami(con, args) -> None:
    columns, rows = run(
        con,
        "select current_account() as account, current_user() as user, "
        "current_role() as role, current_warehouse() as warehouse, "
        "current_database() as database, current_version() as version",
    )
    for key, value in zip(columns, rows[0]):
        print(f"{key:<12} {_fmt(value)}")
    print()
    print("Roles granted to this user (pass --role to use one):")
    try:
        grant_cols, grants = run(con, "show grants to user " + _quote(str(rows[0][1])))
        # SHOW GRANTS TO USER returns every grant, not just role memberships, so
        # filter to granted_on = 'ROLE' and read by column name - the column
        # order is not part of Snowflake's contract.
        on_i = grant_cols.index("granted_on")
        role_i = grant_cols.index("role")
        names = sorted(
            {str(g[role_i]).strip('"') for g in grants if str(g[on_i]).upper() == "ROLE"}
        )
        print("  " + (", ".join(names) if names else "(none visible)"))
        current = str(rows[0][2])
        extra = [n for n in names if n != current]
        if extra:
            print(
                f"\n  Currently using {current}. If a database or table looks absent, "
                f"retry with --role <one of the above> before concluding it is not there."
            )
    except Exception as exc:  # a user may not be able to read its own grants
        print(f"  (could not read: {type(exc).__name__}: {exc})")


def cmd_databases(con, args) -> None:
    _, rows = run(con, "show databases")
    names = _drop_internal([str(r[1]) for r in rows])
    hidden = {n: r for n in names if (r := _nonprod_reason(n))}
    keep = names if args.include_nonprod else [n for n in names if n not in hidden]

    print(f"{len(keep)} databases visible to role {args._role or 'default'}:")
    for name in keep:
        suffix = f"   [{hidden[name]}]" if name in hidden else ""
        print(f"  {name}{suffix}")

    if hidden and not args.include_nonprod:
        print(f"\n{len(hidden)} non-production database(s) hidden:")
        for name, reason in sorted(hidden.items()):
            print(f"  {name}  ({reason})")
        print(
            "\nThese are not what anyone means by default. Do not cite them as where "
            "data lives, and do not include them in a summary unless the request was "
            "specifically about QA or about somebody's sandbox. --include-nonprod "
            "lists them inline; naming one explicitly always works."
        )
    print("\nNext: `schemas <DB>` for a per-schema object count before listing tables.")


def _warn_if_qa(db: str) -> None:
    """Explicitly naming a non-production database is allowed, but say so.

    Reading a QA clone by accident and reporting it as production is a silent
    wrong answer, which is worse than a refusal.
    """
    reason = _nonprod_reason(db)
    if reason is None:
        return
    base = f" Its base database is {_QA_PATTERN.split(db)[0]}." if _is_qa(db) else ""
    print(
        f"NOTE: {db} is a {reason}, not production.{base} Continuing because you "
        f"named it explicitly - do not report these results as production data.\n"
    )


def cmd_schemas(con, args) -> None:
    db = args.database
    _warn_if_qa(db)
    columns, rows = run(
        con,
        "select table_schema, table_type, count(*) as objects "
        f"from {_quote(db)}.information_schema.tables "
        "where table_schema <> 'INFORMATION_SCHEMA' "
        "group by 1, 2 order by 1, 2",
    )
    if not rows:
        print(f"{db}: no objects visible to the current role.")
        return
    total = sum(int(r[2]) for r in rows)
    print(f"{db}: {total} objects across {len({r[0] for r in rows})} schemas\n")
    emit(columns, rows, args.format)
    if total > args.max_rows:
        print(
            f"\nThis database is large ({total} objects). Use "
            f"`tables {db} --schema <SCHEMA>` rather than listing it whole."
        )


def cmd_tables(con, args) -> None:
    db = args.database
    _warn_if_qa(db)
    where = ["table_schema <> 'INFORMATION_SCHEMA'"]
    if args.schema:
        where.append(f"table_schema = {_literal(args.schema)}")
    if args.like:
        where.append(f"table_name ilike {_literal(args.like)}")
    if args.tables_only:
        where.append("table_type = 'BASE TABLE'")
    predicate = " and ".join(where)

    _, counted = run(
        con,
        f"select count(*) from {_quote(db)}.information_schema.tables where {predicate}",
    )
    total = int(counted[0][0])
    if total == 0:
        print("(no matching tables)")
        return

    # Degrade to a summary rather than flooding the caller. Silent truncation
    # reads as "this is all of it", which is worse than refusing.
    if total > args.max_rows and not args.force:
        print(
            f"{total} objects match in {db} - more than --max-rows ({args.max_rows}).\n"
            f"Showing a schema-level summary instead. Narrow with --schema/--like, "
            f"or pass --force to list them all.\n"
        )
        columns, rows = run(
            con,
            "select table_schema, table_type, count(*) as objects "
            f"from {_quote(db)}.information_schema.tables where {predicate} "
            "group by 1, 2 order by 3 desc, 1",
        )
        emit(columns, rows, args.format)
        return

    columns, rows = run(
        con,
        "select table_schema, table_name, table_type, row_count, bytes "
        f"from {_quote(db)}.information_schema.tables where {predicate} "
        "order by table_schema, table_name",
    )
    print(f"{total} objects in {db}\n")
    emit(columns, rows, args.format)


def cmd_columns(con, args) -> None:
    db, schema, table = _split_object(args.table)
    columns, rows = run(
        con,
        "select column_name, data_type, is_nullable, character_maximum_length as max_len, "
        "numeric_precision as prec, numeric_scale as scale, column_default, comment "
        f"from {_quote(db)}.information_schema.columns "
        f"where table_schema = {_literal(schema)} and table_name = {_literal(table)} "
        "order by ordinal_position",
    )
    if not rows:
        print(f"No such table, or not visible to this role: {args.table}")
        return
    print(f"{db}.{schema}.{table} - {len(rows)} columns\n")
    emit(columns, rows, args.format)


def cmd_preview(con, args) -> None:
    db, schema, table = _split_object(args.table)
    ref = f"{_quote(db)}.{_quote(schema)}.{_quote(table)}"
    cols = args.select or "*"
    sql = f"select {cols} from {ref}"
    if args.where:
        sql += f" where {args.where}"
    sql += f" limit {int(args.limit)}"
    columns, rows = run(con, sql)
    print(f"{sql}\n")
    emit(columns, rows, args.format)
    if len(rows) == int(args.limit):
        print(f"\n(stopped at limit {args.limit} - there may be more rows)")


def cmd_find(con, args) -> None:
    pattern = args.pattern if any(c in args.pattern for c in "%_") else f"%{args.pattern}%"
    skipped = 0
    if args.database:
        # An explicitly named database is always honoured, non-prod or not.
        databases = list(args.database)
    else:
        _, rows = run(con, "show databases")
        databases = _drop_internal([str(r[1]) for r in rows])
        if not args.include_nonprod:
            before = len(databases)
            databases = [d for d in databases if not _nonprod_reason(d)]
            skipped = before - len(databases)

    note = f", skipping {skipped} QA clone/sandbox database(s)" if skipped else ""
    print(f"Searching {len(databases)} database(s) for table names like {pattern!r}{note}\n")
    hits = 0
    for db in databases:
        try:
            _, rows = run(
                con,
                "select table_schema, table_name, table_type, row_count "
                f"from {_quote(db)}.information_schema.tables "
                f"where table_name ilike {_literal(pattern)} "
                "and table_schema <> 'INFORMATION_SCHEMA' "
                "order by table_schema, table_name "
                f"limit {int(args.max_rows)}",
            )
        except Exception as exc:
            if args.verbose:
                print(f"{db}: skipped ({type(exc).__name__})")
            continue
        if not rows:
            continue
        hits += len(rows)
        print(f"{db} ({len(rows)}):")
        for schema, name, ttype, nrows in rows:
            suffix = "" if ttype == "BASE TABLE" else f" [{ttype}]"
            print(f"  {db}.{schema}.{name}  rows={_fmt(nrows)}{suffix}")
        print()
    if not hits:
        print("(no matches)")


def cmd_uniqueness(con, args) -> None:
    """Is a candidate key actually unique in real data?

    Snowflake accepts PRIMARY KEY declarations but never enforces them, so a
    declared key can repeat in practice. Anything that treats a key as a row's
    identity has to check this against real rows rather than trusting the DDL.
    """
    db, schema, table = _split_object(args.table)
    ref = f"{_quote(db)}.{_quote(schema)}.{_quote(table)}"
    cols = [c.strip() for c in args.columns.split(",") if c.strip()]
    if not cols:
        raise SystemExit("Pass at least one column")
    key_list = ", ".join(_quote(c) for c in cols)

    _, rows = run(
        con,
        f"select count(*) as total_rows, count(distinct {key_list}) as distinct_keys from {ref}",
    )
    total, distinct = int(rows[0][0]), int(rows[0][1])
    print(f"{db}.{schema}.{table} key ({', '.join(cols)})")
    print(f"  rows          {total}")
    print(f"  distinct keys {distinct}")
    if total == distinct:
        print("  -> unique in current data")
        return
    print(f"  -> NOT UNIQUE: {total - distinct} duplicate row(s)\n")
    columns, dupes = run(
        con,
        f"select {key_list}, count(*) as occurrences from {ref} "
        f"group by {key_list} having count(*) > 1 order by occurrences desc limit 20",
    )
    emit(columns, dupes, args.format)


def cmd_query(con, args) -> None:
    sql = args.sql
    if args.file:
        sql = Path(args.file).read_text(encoding="utf-8")
    columns, rows = run(con, sql)
    if len(rows) > args.max_rows and not args.force:
        print(
            f"{len(rows)} rows returned, showing the first {args.max_rows} "
            f"(--max-rows to raise, --force to print all).\n"
        )
        rows = rows[: args.max_rows]
    emit(columns, rows, args.format)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sf.py",
        description="Read-only Snowflake exploration CLI.",
    )
    parser.add_argument("--env-file", help="File to read SNOWFLAKE_* from (default: backend .env)")
    parser.add_argument("--role", help="Override SNOWFLAKE_ROLE for this run")
    parser.add_argument("--warehouse", help="Override SNOWFLAKE_WAREHOUSE for this run")
    parser.add_argument("--format", choices=("table", "csv", "json"), default="table")
    parser.add_argument(
        "--max-rows",
        type=int,
        default=100,
        help="Cap on rows printed / objects listed before summarising (default 100)",
    )
    parser.add_argument("--force", action="store_true", help="Print past --max-rows anyway")
    parser.add_argument(
        "--include-nonprod",
        action="store_true",
        help="Include QA clones (<BASE>_QA_<ticket>) and sandbox databases (DBT, DATAIKU) "
        "in discovery. Hidden by default; naming one explicitly always works.",
    )
    parser.add_argument("--login-timeout", type=int, default=60)
    parser.add_argument("--network-timeout", type=int, default=60)
    parser.add_argument("-v", "--verbose", action="store_true")

    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("whoami", help="Account, user, role, warehouse, and granted roles")
    sub.add_parser("databases", help="List visible databases")

    p = sub.add_parser("schemas", help="Per-schema object counts for one database")
    p.add_argument("database")

    p = sub.add_parser("tables", help="List tables/views in a database or schema")
    p.add_argument("database")
    p.add_argument("--schema")
    p.add_argument("--like", help="ILIKE pattern on table_name, e.g. 'MAPPING_%%'")
    p.add_argument("--tables-only", action="store_true", help="Exclude views")

    p = sub.add_parser("columns", help="Column detail for DATABASE.SCHEMA.TABLE")
    p.add_argument("table")

    p = sub.add_parser("preview", help="First N rows of DATABASE.SCHEMA.TABLE")
    p.add_argument("table")
    p.add_argument("-n", "--limit", type=int, default=10)
    p.add_argument("--select", help="Column list instead of *")
    p.add_argument("--where", help="WHERE predicate (still read-only guarded)")

    p = sub.add_parser("find", help="Search table names across databases")
    p.add_argument("pattern", help="Substring, or an ILIKE pattern if it contains %% or _")
    p.add_argument("--database", action="append", help="Limit to this database (repeatable)")

    p = sub.add_parser("uniqueness", help="Check a candidate key is unique in real data")
    p.add_argument("table")
    p.add_argument("columns", help="Comma-separated column list")

    p = sub.add_parser("query", help="Run one read-only statement")
    p.add_argument("sql", nargs="?", default="")
    p.add_argument("--file", help="Read the statement from a file instead")

    return parser


def main() -> int:
    args = build_parser().parse_args()
    handlers = {
        "whoami": cmd_whoami,
        "databases": cmd_databases,
        "schemas": cmd_schemas,
        "tables": cmd_tables,
        "columns": cmd_columns,
        "preview": cmd_preview,
        "find": cmd_find,
        "uniqueness": cmd_uniqueness,
        "query": cmd_query,
    }

    if args.command == "query" and not (args.sql or args.file):
        print("Pass a statement, or --file.", file=sys.stderr)
        return 2

    try:
        con = connect(args)
    except snowflake.connector.errors.Error as exc:
        print(f"Snowflake connect failed: {exc}", file=sys.stderr)
        return 1

    args._role = _settings(args).get("SNOWFLAKE_ROLE")
    try:
        handlers[args.command](con, args)
    except UnsafeSqlError as exc:
        print(f"Refused: {exc}", file=sys.stderr)
        return 2
    except snowflake.connector.errors.Error as exc:
        print(f"Snowflake error: {exc}", file=sys.stderr)
        return 1
    finally:
        con.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
