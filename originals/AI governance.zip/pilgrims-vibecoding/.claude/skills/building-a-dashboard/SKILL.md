---
name: building-a-dashboard
description: "Use when someone asks for a report, dashboard, chart, KPI, table or screen in the vibecoding kit — anything of the form \"show me X\" or \"add a chart of Y\" or \"can I see Z by plant\". Covers the whole path: finding the real table in Snowflake, getting the query right before building anything, turning rows into charts with useSql, adding filters, and adding a page. Also covers the four mistakes that make a page render blank."
---

# Building a dashboard

The path from "show me weekly volume by plant" to a screen. Follow it in order — most wasted time here comes from building the page before the query works.

## 1. Find the real table

**Never guess a table name.** Use the `exploring-snowflake` skill. Two things about this account will bite you:

- QA clones look identical to production (`SALES` and `SALES_QA_10315` both have a `MART_CIRCANA_SALES_PPC`). The script hides them by default. Don't defeat that filter.
- A table that "doesn't exist" is usually a role that can't see it. `whoami` first.

Ask the person what they call the thing, then search for it:

```bash
uv run .claude/skills/exploring-snowflake/scripts/sf.py find 'BROILER%'
uv run .claude/skills/exploring-snowflake/scripts/sf.py columns LIVE_OPERATIONS.MART_BROILER.F_PLACEMENTS
uv run .claude/skills/exploring-snowflake/scripts/sf.py preview LIVE_OPERATIONS.MART_BROILER.F_PLACEMENTS -n 5
```

Preview before you aggregate. It is the fastest way to learn that a "date" column is a string, that plant names have trailing spaces, or that the grain is one row per bird per day rather than what you assumed.

## 2. Get the query right first

Write the query so it returns **exactly the shape the chart needs** — one row per bar, one row per point on the line. Aggregate in SQL, not in JavaScript. Snowflake is better at it and the page stays trivial.

Run it before you build anything, in the Explore tab or with `sf.py query`. If the numbers look surprising, they are surprising now, not after you have built three cards on top of them.

Two things to bake in:

- **Alias every column to the name the page will use**, uppercase: `sum(CASES) as TOTAL_CASES`. Snowflake uppercases unquoted names anyway, so matching it avoids the most common blank-chart bug.
- **Order it.** A line chart plots rows in the order they arrive; unordered dates zigzag.

```sql
select
  date_trunc('week', SHIP_DATE) as WEEK,
  PLANT_NAME as PLANT,
  sum(CASES) as TOTAL_CASES
from SALES.MART_SALES.F_SHIPMENTS
where SHIP_DATE >= dateadd(week, -12, current_date())
group by 1, 2
order by 1
```

## 3. Build the page

One screen is one file in `src/pages/`. Copy the shape of `dashboard.tsx`.

```tsx
import { useSql } from '@/lib/use-sql';
import { formatCompact } from '@/lib/format';
import { BarChart, ChartCard, ReportGrid, ReportShell } from '@/ui';

const VOLUME_SQL = `select PLANT_NAME as PLANT, sum(CASES) as TOTAL_CASES from ... group by 1 order by 2 desc`;

export function Volume() {
  const volume = useSql(VOLUME_SQL);

  return (
    <ReportShell title="Volume by plant" description="Last 12 weeks">
      <ChartCard.Root status={volume.status} error={volume.error}>
        <ChartCard.Header>
          <ChartCard.Title>Cases shipped</ChartCard.Title>
        </ChartCard.Header>
        <ChartCard.Content>
          <BarChart
            horizontal
            labels={volume.rows.map((row) => row.PLANT)}
            series={[{ label: 'Cases', data: volume.rows.map((row) => Number(row.TOTAL_CASES)) }]}
          />
        </ChartCard.Content>
      </ChartCard.Root>
    </ReportShell>
  );
}
```

Then register it in `App.tsx`'s `PAGES` array — one line. That is the whole routing story.

`useSql` gives you `rows`, `columns`, `status`, `error` and `refresh`. Passing `status` and `error` to a `*Card.Root` is what makes loading skeletons and error states appear; you never write those by hand. See `pilgrims-look-and-feel` for what else is in `src/ui`.

## Turning rows into a chart

One row per label, and one `series` entry per line/bar colour.

```tsx
// One series
labels={rows.map((r) => r.WEEK)}
series={[{ label: 'Cases', data: rows.map((r) => Number(r.TOTAL_CASES)) }]}

// One line per plant, from a query with a PLANT column
const plants = [...new Set(rows.map((r) => r.PLANT))];
const weeks = [...new Set(rows.map((r) => r.WEEK))];
series={plants.map((plant) => ({
  label: plant,
  data: weeks.map((week) =>
    Number(rows.find((r) => r.WEEK === week && r.PLANT === plant)?.TOTAL_CASES ?? 0)
  ),
}))}
```

**Snowflake returns decimal columns as JSON strings** — `"80.6"`, not `80.6`. The charts, `DataTable` and the `format*` helpers all coerce for you, so passing rows straight through is fine. **Arithmetic you write yourself does not.** `sum + row.TOTAL` concatenates strings into nonsense; `sum + Number(row.TOTAL)` is right. Integers come back as numbers, so this bites on averages, percentages and money, which is exactly where a wrong total is hardest to spot.

More than about eight categories and the colours stop meaning anything — `groupIntoOther(items, 7)` collapses the tail into one "Other" bar.

## Adding a filter

`useState` plus a template string. The query text changes, `useSql` notices, it re-runs. There is no cache to invalidate and no refetch to wire.

```tsx
const [plant, setPlant] = useState('All');
const clause = plant === 'All' ? '' : `where PLANT_NAME = '${plant.replace(/'/g, "''")}'`;
const volume = useSql(`select ... from ... ${clause} group by 1`);

<ReportShell toolbar={<Select value={plant} onValueChange={setPlant} options={['All', ...plants]} />}>
```

Escape the quotes as shown. Not for security — the backend only allows reads — but because a plant called `Ol' Mill` produces a syntax error that reads like a bug in the page.

Populate the dropdown from the warehouse rather than hardcoding it, so it can't drift: `const plants = useSql('select distinct PLANT_NAME as PLANT from ... order by 1')`.

Pass `null` to `useSql` to hold off until a choice is made.

## The four reasons a page renders blank

In the order they actually happen:

1. **Column name case.** `row.total_cases` is `undefined`; `row.TOTAL_CASES` is the value. Snowflake uppercases unquoted aliases.
2. **Strings where numbers belong.** Components coerce; your own `reduce` and `/` do not. A KPI reading `"12001100"` where you expected `2,300` is two strings added together.
3. **Zero rows.** The query succeeded and matched nothing. Check the filter values against real data in the Explore tab; `'Plant A'` vs `PLANT_A` is the usual culprit.
4. **A chart with no height.** Chart.js needs a fixed height. `ChartCard.Content` provides one — a chart dropped into a bare `<div>` collapses to nothing. Pass `height={320}` to make one taller.

## What not to do

- **Don't aggregate in JavaScript** what SQL can do. Summing 200k rows in the browser is slow and the code is worse.
- **Don't add a router, a query library, or a state manager.** `useState` and the `PAGES` array cover everything this kit is for.
- **Don't build the page before the query returns rows.** Every time.
- **Don't hand-roll cards or tables.** `src/ui` has them, and hand-rolled ones are what make a prototype look like a prototype.
