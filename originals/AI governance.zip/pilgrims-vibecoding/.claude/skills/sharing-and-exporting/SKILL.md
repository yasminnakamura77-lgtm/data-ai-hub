---
name: sharing-and-exporting
description: "Use when someone wants data or a screen out of the prototype — \"can I get this in Excel\", \"download as CSV\", \"export this table\", \"I need to send this to my boss\", \"can my team see this\", \"put this in a deck\", \"can you email me this report\". Covers adding a download button, and the honest answer about who can see a localhost prototype."
risk: safe
source: internal
date_added: "2026-08-05"
---

# Sharing and exporting

Two requests, and both arrive within about a week of a prototype being useful: *"can I get this in Excel?"* and *"can I show this to my boss?"* One is easy, one has no good technical answer, and both are worth handling well because they mean the thing is working.

## First, find out what they actually need

Ask before building. The four needs look identical in the request and have completely different answers:

| What they say | What they often mean | Answer |
|---|---|---|
| "Can I get this in Excel?" | They want to pivot it their own way, or paste it into a report they already send | A download button on the page |
| "I need to send this to my boss" | One number, in an email or a slide, today | A screenshot. Say so — it's the right answer and it takes ten seconds |
| "Can my team see this?" | Five people want to open it whenever they like | This is the handoff conversation, not an export |
| "Can you email me this?" | They want it on their phone / away from their desk | Screenshot or export. There's no server to point them at |

## Adding a download button

Write the rows currently on screen to a CSV. No library — `papaparse` and friends are not going in this kit.

**Export what they are looking at, not the whole table.** If a filter is set to one plant, the download is that plant. If they want the underlying detail instead of the aggregated chart data, that's a second, separate query — ask which, because "the data behind this chart" and "the transactions behind this number" are different asks and the second one is usually what a person who says "so I can dig into it" means.

```tsx
import { Button } from '@/ui';
import type { Row } from '@/lib/use-sql';

function downloadCsv(rows: Row[], filename: string) {
  if (!rows.length) return;
  const cols = Object.keys(rows[0]);
  const cell = (value: unknown) => {
    const text = value == null ? '' : String(value);
    return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const csv = [
    cols.join(','),
    ...rows.map((row) => cols.map((col) => cell(row[col])).join(',')),
  ].join('\r\n');

  // The UTF-8 byte-order mark is what makes Excel read this as UTF-8 rather than
  // mangling accents. Write it as the escape; a pasted invisible character is worse.
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
```

Then put it in the page's toolbar, disabled until there's something to download:

```tsx
<ReportShell
  title="Volume by plant"
  toolbar={
    <Button
      variant="outline"
      size="sm"
      disabled={!volume.rows.length}
      onClick={() => downloadCsv(volume.rows, 'volume-by-plant.csv')}
    >
      Download CSV
    </Button>
  }
>
```

Details that turn into a complaint if you skip them:

- **The BOM.** Without it Excel renders `Peña` as `PeÃ±a`. Plant and customer names in this warehouse contain accents.
- **Quote anything containing a comma, a quote or a newline** — the `cell` helper above does it. A customer name with a comma silently shifts every column right for that row, which looks like corrupt data.
- **Name the file after the report, and include the filter** — `volume-by-plant-2026-08.csv`, not `export.csv`. They will have four of these in Downloads by Friday.
- **Dates and long codes.** Excel will helpfully turn `05/08` into a date and strip leading zeros from a plant code. If a column is an identifier, say so when you hand it over; there is no fixing it from the CSV side without making the file uglier than it's worth.
- **Check `truncated`.** `useSql` returns it — the backend caps rows. A download that silently stops at the cap is worse than no download. If it's set, tell them, and aggregate in SQL rather than exporting more.

If they'd rather have the raw rows than a page, the **Explore tab** already runs any query and shows the result — often the whole answer, with no page to build.

## "Can I show this to my boss?"

Be straight about this. **The app runs on their machine only.** There is no URL anyone else can open, and that is not a setting someone forgot to turn on.

The real options, in the order they're usually right:

1. **A screenshot** (`Win+Shift+S`, or `Cmd+Shift+4` on Mac). For a slide, an email or a "look at this" in a meeting, this is the answer. Don't over-engineer past it.
2. **Show it live, together.** Sitting next to them, or sharing their screen in Teams. Zero work, and a demo lands far better than a picture. If it's for a scheduled meeting, offer to check the app starts cleanly beforehand — a first-query SSO popup mid-demo is avoidable.
3. **Send the folder.** `.\make-zip.ps1` produces a zip with no credentials in it. Set the expectation honestly: the recipient needs Node, pnpm, uv, git and Claude Code installed, their own Snowflake access and the VPN, and **they will see whatever their own Snowflake role can see** — which may not be the same data, and may be nothing. Fine for a colleague who also builds things; a poor way to show a number to an executive.
4. **More than a handful of people need it regularly** → that's `handing-off-to-engineering`. Say it plainly: the way this gets a URL that people can open is the platform team building it, and the prototype is what makes that a short conversation instead of a long one.

## What not to do

- **Don't expose the dev server to the network.** No `--host`, no port forwarding, no tunnel, no ngrok. It has no authentication of any kind and it queries production Snowflake with the person's own credentials.
- **Don't deploy it.** Not to a VM, not to a shared drive, not to anyone's IIS. This kit is not built to be deployed and nothing about that changes because the prototype turned out to be good.
- **Don't build a login, a user table, or a permissions system.** If access control is a requirement, the requirement belongs in the handoff document, not in an afternoon.
- **Don't ever send `.env` or credentials.** `make-zip.ps1` excludes `.env` deliberately; don't work around it, and don't paste connection details into a chat or an email.
- **Don't set up a scheduled email of the report.** It needs a machine that's always on, always on the VPN, with a live SSO session. It will break quietly and nobody will notice the report stopped arriving. That's a production feature — put it in the handoff.

## One thing to say once

An exported file leaves the guarded environment. Inside the app, the person only ever sees what their Snowflake role permits; **a CSV in someone's inbox has no such limit.** Say it once, plainly, when you hand over the first export — plant-level cost or customer-level data forwarded to the wrong person is the realistic risk here, not anything technical. Then let them decide; they know their business and their obligations better than you do. Don't repeat it every time.
