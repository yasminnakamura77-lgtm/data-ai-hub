// PostToolUse hook: after any frontend edit, typecheck the frontend.
//
// Why this exists: a TypeScript error stops Vite rebuilding, so the browser keeps
// showing the LAST WORKING VERSION of the page. To the person that looks like
// "Claude said it changed it and nothing happened" — a tooling problem, which it
// isn't. Nobody in this kit reads the frontend terminal, so this reads it for them.
//
// Exits 0 (silent) when there is nothing to say, 2 with the compiler output when
// the code is broken.

import { execSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const FRONTEND = path.join(ROOT, 'app', 'frontend');

function editedFile() {
  try {
    const input = JSON.parse(readFileSync(0, 'utf8'));
    return input?.tool_input?.file_path ?? '';
  } catch {
    return '';
  }
}

const edited = editedFile().replace(/\\/g, '/');
if (!/(^|\/)app\/frontend\/.*\.(ts|tsx)$/.test(edited)) process.exit(0);

// Before the first `pnpm install` there is no compiler to run. Setup's job, not ours.
if (!existsSync(path.join(FRONTEND, 'node_modules'))) process.exit(0);

try {
  execSync('pnpm run typecheck', { cwd: FRONTEND, stdio: 'pipe', timeout: 80_000 });
  process.exit(0);
} catch (error) {
  const output = `${error.stdout ?? ''}${error.stderr ?? ''}`.trim();

  // A crashed/missing toolchain is not a broken page — don't send the agent chasing it.
  if (!output || /ERR_PNPM|command not found|ENOENT/i.test(output)) process.exit(0);

  console.error(
    [
      'TypeScript is failing, so Vite has stopped rebuilding: the browser is still showing the',
      'previous working version of the page. Fix this before telling the person to look at it —',
      'if they reload now they will see the old screen and think nothing happened.',
      '',
      output,
    ].join('\n')
  );
  process.exit(2);
}
