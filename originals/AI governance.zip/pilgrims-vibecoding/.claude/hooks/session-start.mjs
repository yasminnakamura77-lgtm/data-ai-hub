// SessionStart hook: report where this machine actually is, before the first request.
//
// Two things an agent otherwise guesses at: whether setup ever happened, and what
// was built in sessions it can't remember. Both are cheap to look up and expensive
// to get wrong — rebuilding a page that already exists, or asking for Snowflake
// details that are already in .env.

import { execSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

const git = (args) => execSync(`git ${args}`, { cwd: ROOT, stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim();

const lines = ['Kit state at session start:'];

// Setup
const envReady = existsSync(path.join(ROOT, 'app', 'backend', '.env'));
const installed = existsSync(path.join(ROOT, 'app', 'frontend', 'node_modules'));
if (!envReady || !installed) {
  lines.push(
    `- Setup is incomplete: ${!envReady ? 'app/backend/.env is missing' : 'frontend packages are not installed'}.` +
      ' Use the getting-set-up skill before anything else.'
  );
} else {
  lines.push('- Setup looks done (.env present, packages installed).');
}

// History
if (!existsSync(path.join(ROOT, '.git'))) {
  lines.push('- No git history yet. Start it (getting-set-up, step 2) before changing any file —');
  lines.push('  until then nothing the person builds can be brought back.');
} else {
  try {
    const dirty = git('status --porcelain');
    lines.push(
      dirty
        ? `- ${dirty.split('\n').length} uncommitted file(s) from an earlier session. Commit them before starting something new:\n${dirty.split('\n').map((l) => `    ${l}`).join('\n')}`
        : '- Everything is committed.'
    );
    const log = git('log --pretty=format:"%ad  %s" --date=short -6');
    if (log) lines.push('- Recent work:', ...log.split('\n').map((l) => `    ${l.replace(/^"|"$/g, '')}`));
  } catch {
    lines.push('- git is installed but this folder has no commits yet.');
  }
}

console.log(lines.join('\n'));
