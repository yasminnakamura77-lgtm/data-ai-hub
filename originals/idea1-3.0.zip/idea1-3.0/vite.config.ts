import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';

// @pilgrims/config ships compiled dist and is deliberately excluded from the
// PLATFORM_DEV source alias, so import the preset from its built dist directly
// (avoids needing @pilgrims/config installed in this prototype's node_modules).
import { createPlatformDevAlias } from '../pilgrims-core-components/packages/config/dist/vite-preset.js';

// Force PLATFORM_DEV on: resolve @pilgrims/* straight to the sibling
// pilgrims-core-components source (hot-reload, single React instance via dedupe).
process.env.PLATFORM_DEV ||= '1';

const platformDev = createPlatformDevAlias({ appRoot: process.cwd() });

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: platformDev.alias, dedupe: platformDev.dedupe },
  server: {
    port: 5175,
    fs: { allow: platformDev.fsAllow },
    // Proxy the thin local dev API (dev-api/serve.py) so the app fetches
    // same-origin /api/* — no CORS, real data from portfolio.db.
    proxy: { '/api': 'http://127.0.0.1:8099' },
  },
});
