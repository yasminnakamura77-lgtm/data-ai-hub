@echo off
cd /d "%~dp0"
pnpm dev -- --open --port 5176