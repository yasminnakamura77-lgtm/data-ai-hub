import { useState } from 'react';

import { ThemeToggle } from '@pilgrims/ui';

import type { Area } from './mock';
import { ApplicationDetail } from './screens/ApplicationDetail';
import { AssetDetail } from './screens/AssetDetail';
import { Landing } from './screens/Landing';
import { Lineage } from './screens/Lineage';
import { MetricDetail } from './screens/MetricDetail';
import { MetricForm } from './screens/MetricForm';
import { RequestSource } from './screens/RequestSource';
import { Browse, type BrowseKind } from './screens/Browse';
import { HubAssistant } from './HubAssistant';

export type View =
  | { name: 'landing' }
  | { name: 'browse'; kind: BrowseKind }
  | { name: 'asset'; id: string }
  | { name: 'app'; id: string }
  | { name: 'metric'; id: string }
  | { name: 'lineage'; id: string }
  | { name: 'request-source' }
  | { name: 'metric-new' }
  | { name: 'metric-edit'; id: string };

export type Navigate = (v: View) => void;

const NAV: { label: string; go: View }[] = [
  { label: 'Home', go: { name: 'landing' } },
  { label: 'Metrics', go: { name: 'browse', kind: 'metrics' } },
  { label: 'Data', go: { name: 'browse', kind: 'sources' } },
  { label: 'Applications', go: { name: 'browse', kind: 'apps' } },
  { label: 'Glossary', go: { name: 'browse', kind: 'terms' } },
];

// Deep-linkable URLs (e.g. ?v=metric:prod-egg-cost, ?v=browse:sources) —
// the design requires every object to have a shareable URL a Tower can link to.
function viewFromUrl(): View {
  const v = new URLSearchParams(window.location.search).get('v');
  if (v?.startsWith('browse:')) return { name: 'browse', kind: v.slice('browse:'.length) as BrowseKind };
  if (v?.startsWith('asset:')) return { name: 'asset', id: v.slice('asset:'.length) };
  if (v?.startsWith('app:')) return { name: 'app', id: v.slice('app:'.length) };
  if (v?.startsWith('metric:')) return { name: 'metric', id: v.slice('metric:'.length) };
  if (v?.startsWith('lineage:')) return { name: 'lineage', id: v.slice('lineage:'.length) };
  if (v?.startsWith('metric-edit:')) return { name: 'metric-edit', id: v.slice('metric-edit:'.length) };
  if (v === 'request-source') return { name: 'request-source' };
  if (v === 'metric-new') return { name: 'metric-new' };
  return { name: 'landing' };
}

function viewToUrl(v: View): string {
  if (v.name === 'landing') return window.location.pathname;
  if (v.name === 'browse') return `?v=browse:${v.kind}`;
  if (v.name === 'request-source') return '?v=request-source';
  if (v.name === 'metric-new') return '?v=metric-new';
  return `?v=${v.name}:${'id' in v ? v.id : ''}`;
}

export function App() {
  const [view, setView] = useState<View>(viewFromUrl);
  const [area, setArea] = useState<Area | 'All'>('All');

  const navigate: Navigate = (v) => {
    setView(v);
    window.history.replaceState(null, '', viewToUrl(v));
    window.scrollTo({ top: 0 });
  };

  return (
    <div data-application="data-ai-hub" className="min-h-svh bg-background text-foreground">
      {/* Brand chrome — draws from Pilgrim's navy, per platform convention. */}
      <header className="sticky top-0 z-20 border-b border-white/10 bg-brand-navy text-white">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-6 px-6">
          <button
            onClick={() => navigate({ name: 'landing' })}
            className="flex items-center gap-2 font-semibold tracking-tight"
          >
            <span className="grid size-7 place-items-center rounded-md bg-white/15">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="7.5" cy="12" r="2.1" fill="#fff" />
                <circle cx="16.5" cy="7.5" r="1.8" fill="#fff" opacity="0.85" />
                <circle cx="16.5" cy="16.5" r="1.8" fill="#fff" opacity="0.85" />
                <path
                  d="M9.2 11.2 14.9 8.3 M9.2 12.8 14.9 15.7"
                  stroke="#fff"
                  strokeWidth="1.4"
                  strokeLinecap="round"
                  opacity="0.85"
                />
              </svg>
            </span>
            Pilgrim&apos;s <span className="font-normal text-white/70">Data &amp; AI Hub</span>
          </button>
          <nav className="ml-4 hidden items-center gap-1 md:flex">
            {NAV.map((item) => {
              const isActive =
                view.name === item.go.name &&
                (item.go.name !== 'browse' || (item.go as { kind: string }).kind === (view as { kind?: string }).kind);
              return (
                <button
                  key={item.label}
                  onClick={() => navigate(item.go)}
                  className={`rounded-md px-3 py-1.5 text-sm transition-colors ${
                    isActive ? 'bg-white/15 text-white' : 'text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-3">
            <span className="hidden text-xs text-white/60 sm:inline">local · admin (dev auth)</span>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {view.name === 'landing' && <Landing area={area} setArea={setArea} navigate={navigate} />}
        {view.name === 'browse' && <Browse kind={view.kind} navigate={navigate} />}
        {view.name === 'asset' && <AssetDetail id={view.id} navigate={navigate} />}
        {view.name === 'app' && <ApplicationDetail id={view.id} navigate={navigate} />}
        {view.name === 'metric' && <MetricDetail id={view.id} navigate={navigate} />}
        {view.name === 'lineage' && <Lineage id={view.id} navigate={navigate} />}
        {view.name === 'request-source' && <RequestSource navigate={navigate} />}
        {view.name === 'metric-new' && <MetricForm mode="create" navigate={navigate} />}
        {view.name === 'metric-edit' && <MetricForm mode="edit" metricId={view.id} navigate={navigate} />}
      </main>
      <HubAssistant />
    </div>
  );
}
