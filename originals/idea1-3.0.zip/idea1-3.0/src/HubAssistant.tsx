import { useState, type FormEvent } from 'react';

type ChatMessage = { author: 'assistant' | 'user'; text: string };

const STARTER_REPLY =
  'I can help you investigate data assets, explain business signals, identify recurring AI failure patterns, or navigate the Hub.';

export function HubAssistant() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const addAssistantMessage = (text: string) => setMessages((current) => [...current, { author: 'assistant', text }]);

  const sendMessage = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const text = input.trim();
    if (!text) return;
    setMessages((current) => [...current, { author: 'user', text }]);
    setInput('');
    window.setTimeout(() => addAssistantMessage(STARTER_REPLY), 350);
  };

  return (
    <>
      <button type="button" className="hub-assistant-orb" aria-label="Open Hub Assistant" aria-expanded={open} onClick={() => setOpen((current) => !current)}>
        <span className="hub-assistant-alert">1</span>
        <span className="hub-assistant-robot" aria-hidden="true"><i /><i /><b /></span>
      </button>

      <aside className={`hub-assistant-panel ${open ? 'is-open' : ''}`} aria-hidden={!open} aria-label="Hub Assistant">
        <header className="hub-assistant-header">
          <div className="hub-assistant-identity">
            <span className="hub-assistant-mini"><span className="hub-assistant-robot mini" aria-hidden="true"><i /><i /><b /></span></span>
            <div><strong>Hub Assistant</strong><small>Data &amp; AI intelligence companion</small></div>
          </div>
          <button type="button" className="hub-assistant-close" aria-label="Close Hub Assistant" onClick={() => setOpen(false)}>×</button>
        </header>

        <div className="hub-assistant-body">
          <div className="hub-assistant-welcome"><strong>Good morning.</strong><p>I monitor the Hub for business signals, recurring patterns and useful insights.</p></div>

          <section className="hub-assistant-card opportunity">
            <div className="hub-assistant-card-head"><span><em className="assistant-icon blue">✦</em><div><small>OPPORTUNITY RADAR</small><h3>Change recommended</h3></div></span><b className="assistant-status">DETECTED</b></div>
            <h4>Consolidate duplicate customer datasets</h4>
            <p>RAW.CRM_CUSTOMERS and RAW.CUSTOMER_MASTER contain highly overlapping records. Consolidating them could reduce duplication and simplify the data landscape.</p>
            <div className="hub-assistant-meta"><span>Detected from<strong>Data Catalogue</strong></span><span>Confidence<strong>94%</strong></span></div>
            <button type="button" className="hub-assistant-primary" onClick={() => addAssistantMessage('I identified significant overlap between RAW.CRM_CUSTOMERS and RAW.CUSTOMER_MASTER. Consolidating the two datasets could reduce duplication. Confidence: 94%.')}>Review change →</button>
          </section>

          <section className="hub-assistant-library">
            <div className="hub-assistant-card-head"><span><em className="assistant-icon amber">!</em><div><small>AI FAILURE LIBRARY</small><h3>Patterns identified</h3></div></span><b className="assistant-count">2 possible failures</b></div>
            <p className="hub-assistant-library-copy">Similar situations happened before. These patterns may help prevent future failures.</p>
            <FailureCard title="Potential demand drop" match="91% match" color="medium" text="A combination of declining orders and lower customer activity has appeared again. In the last 3 occurrences, this pattern was followed by a significant drop in demand." onReview={addAssistantMessage} />
            <FailureCard title="Entity hallucination" match="76% match" color="high" text="A previous run generated entities that were not present in the source dataset." onReview={addAssistantMessage} />
          </section>

          <div className="hub-assistant-messages" aria-live="polite">
            {messages.map((message, index) => <div key={index} className={`hub-assistant-message ${message.author}`}>{message.text}</div>)}
          </div>
        </div>

        <form className="hub-assistant-input" onSubmit={sendMessage}>
          <input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask the Hub Assistant..." aria-label="Ask the Hub Assistant" />
          <button type="submit" aria-label="Send message">↑</button>
        </form>
      </aside>
    </>
  );
}

function FailureCard({ title, match, color, text, onReview }: { title: string; match: string; color: string; text: string; onReview: (message: string) => void }) {
  return <article className="hub-assistant-failure"><div className="hub-assistant-failure-top"><strong><i className={`hub-assistant-severity ${color}`} />{title}</strong><span>{match}</span></div><b>Why this may happen</b><p>{text}</p><footer><span>Pattern observed previously</span><button type="button" onClick={() => onReview(`The “${title}” pattern has been identified in previous runs. The Hub can use this historical pattern to detect similar situations earlier.`)}>View pattern →</button></footer></article>;
}
